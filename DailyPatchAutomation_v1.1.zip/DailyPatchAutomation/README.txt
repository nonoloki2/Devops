DAILY PATCH AUTOMATION

1. Execute DailyPatchAutomation.ps1 in Windows PowerShell 5.1 as an account with SQL/SCCM/share access.
2. Validate the fields, click Test Connections, then Run Full Process.
3. Stage 2 starts only after Stage 1 creates and validates the exact XLSX.
4. For scheduled execution: powershell.exe -ExecutionPolicy Bypass -File .\DailyPatchAutomation.ps1 -NoGui -ConfigFile .\DailyPatchAutomation.json

IMPORTANT: Review CollectionId, DeploymentFilter and output paths before the first production run.

v1.1 correction: PowerShell 5.1 here-string terminators were aligned to column 1 to prevent ParserError.
