﻿#requires -Version 5.1
<#+
.SYNOPSIS
  Executa Grid + MS Daily Patch em sequência garantida.
.DESCRIPTION
  A etapa 2 somente inicia após a etapa 1 criar e validar o XLSX.
#>
[CmdletBinding()]
param(
    [switch]$NoGui,
    [string]$ConfigFile = (Join-Path $PSScriptRoot 'DailyPatchAutomation.json')
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

function Get-AutomaticEnvironment {
    $result = [ordered]@{ SmsProvider=''; SqlServer=''; SiteCode=''; Database=''; DomainSuffix=''; GridOutputDirectory=''; ReportDirectory=''; LocalWorkingDirectory=(Join-Path $env:TEMP 'DailyPatchAutomation'); CollectionId=''; DeploymentFilter='Desktop Deployment - Enterprise Production - Windows - 2026 - 07'; CollectionFilter='*Desktop Clients*' }
    try { $result.DomainSuffix = (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).Domain } catch {}
    try {
        $drives = Get-PSDrive -PSProvider CMSite -ErrorAction SilentlyContinue
        if ($drives) { $result.SiteCode = [string]($drives | Select-Object -First 1).Name }
    } catch {}
    if ($result.SiteCode) { $result.Database = "CM_$($result.SiteCode)" }
    return [PSCustomObject]$result
}

function Test-AutomationConfiguration {
    param([hashtable]$Config)
    $required = 'SqlServer','Database','SmsProvider','SiteCode','DomainSuffix','CollectionId','GridOutputDirectory','ReportDirectory','LocalWorkingDirectory','DeploymentFilter'
    foreach($name in $required){ if([string]::IsNullOrWhiteSpace([string]$Config[$name])){ throw "Campo obrigatório não preenchido: $name" } }
    $cn = New-Object Data.SqlClient.SqlConnection("Server=$($Config.SqlServer);Database=$($Config.Database);Integrated Security=True;TrustServerCertificate=True;Connection Timeout=8")
    try { $cn.Open() } finally { if($cn.State -eq 'Open'){ $cn.Close() } }
    if(-not (Test-Path "\\$($Config.SmsProvider)\admin$")){ Write-Warning "Não foi possível validar ADMIN$ no SMS Provider. A execução ainda poderá funcionar via WinRM." }
    foreach($p in 'GridOutputDirectory','ReportDirectory','LocalWorkingDirectory'){
        if(-not (Test-Path -LiteralPath $Config[$p])){ New-Item -ItemType Directory -Path $Config[$p] -Force | Out-Null }
    }
}

function Invoke-FullAutomation {
    param([hashtable]$Config)
    Test-AutomationConfiguration $Config
    Write-Host "`nETAPA 1/2 - GRID REPORT" -ForegroundColor Cyan
    $gridParams = @{
        Server=$Config.SqlServer; Database=$Config.Database; DeploymentFilter=$Config.DeploymentFilter;
        CollectionFilter=@($Config.CollectionFilter); DomainSuffix=$Config.DomainSuffix;
        OutputDirectory=$Config.GridOutputDirectory; Auto=$true; AllCollections=$true
    }
    $grid = Invoke-GridReport @gridParams
    if(-not $grid.Success){ throw 'A etapa Grid não confirmou sucesso.' }
    Write-Host "ETAPA 1 concluída: $($grid.ReportPath)" -ForegroundColor Green
    Write-Host "`nETAPA 2/2 - MS DAILY PATCH" -ForegroundColor Cyan
    $daily = Invoke-DailyPatchReport -GridReportPath $grid.ReportPath -SCCMServer $Config.SmsProvider -SiteCode $Config.SiteCode -CollectionID $Config.CollectionId -ReportDirectory $Config.ReportDirectory -LocalWorkingDirectory $Config.LocalWorkingDirectory
    Write-Host "ETAPA 2 concluída: $($daily.FullName)" -ForegroundColor Green
    Write-Host "`nPROCESSO COMPLETO FINALIZADO COM SUCESSO." -ForegroundColor Green
    return $daily
}

function Invoke-GridReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$DeploymentFilter,
        [string[]]$CollectionFilter = @('%'),
        [Parameter(Mandatory)][string]$DomainSuffix,
        [Parameter(Mandatory)][string]$OutputDirectory,
        [switch]$Auto,
        [switch]$AllCollections
    )

    $ErrorActionPreference = 'Stop'
    if (-not (Test-Path -LiteralPath $OutputDirectory)) {
        New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    }
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    # === WIN32 HELPERS (MoveWindow para GridView) ===
    if (-not ([System.Management.Automation.PSTypeName]'Win32Window').Type) {
        Add-Type -TypeDefinition @'
    using System;
    using System.Runtime.InteropServices;
    public class Win32Window {
        [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd, int x, int y, int w, int h, bool repaint);
        [DllImport("user32.dll")] public static extern IntPtr FindWindow(string cls, string title);
        [DllImport("user32.dll")] public static extern int GetSystemMetrics(int n);
    }
    '@ -Language CSharp
    }
    function Show-GridViewWide {
        param ([object[]]$InputData, [string]$Title, [string]$OutputMode = 'Single')
        $ResizeScript = {
            param($T)
            $gvHwnd = [IntPtr]::Zero
            for ($i = 0; $i -lt 50; $i++) {
                Start-Sleep -Milliseconds 100
                $gvHwnd = [Win32Window]::FindWindow($null, $T)
                if ($gvHwnd -ne [IntPtr]::Zero) { break }
            }
            if ($gvHwnd -ne [IntPtr]::Zero) {
                $screenW = [Win32Window]::GetSystemMetrics(0)
                $screenH = [Win32Window]::GetSystemMetrics(1)
                $winW    = [int]($screenW * 0.92)
                $winH    = [int]($screenH * 0.80)
                $posX    = [int](($screenW - $winW) / 2)
                $posY    = [int](($screenH - $winH) / 2)
                [Win32Window]::MoveWindow($gvHwnd, $posX, $posY, $winW, $winH, $true) | Out-Null
            }
        }
        $Runspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
        $Runspace.Open()
        $Ps = [System.Management.Automation.PowerShell]::Create()
        $Ps.Runspace = $Runspace
        $Ps.AddScript($ResizeScript).AddArgument($Title) | Out-Null
        $Ps.BeginInvoke() | Out-Null
        if ($OutputMode -eq 'Single') {
            $Result = $InputData | Out-GridView -Title $Title -OutputMode Single
        } else {
            $Result = $InputData | Out-GridView -Title $Title -OutputMode Multiple
        }
        $Ps.Dispose()
        $Runspace.Close()
        return $Result
    }
    # === CARREGA TABELA DE ERROS DA DLL REMOTA ===
    $ErrorTable = @{}
    $RemotePaths = @(
        "\$Server\D$\Program Files\Microsoft Configuration Manager\AdminConsole\bin\SrsResources.dll",
        "\$Server\C$\Program Files\Microsoft Configuration Manager\AdminConsole\bin\SrsResources.dll",
        "\$Server\C$\Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin\SrsResources.dll",
        "\$Server\D$\Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin\SrsResources.dll",
        "\$Server\C$\Program Files\Microsoft Configuration Manager\bin\X64\SrsResources.dll",
        "\$Server\D$\Program Files\Microsoft Configuration Manager\bin\X64\SrsResources.dll"
    )
     
    $FoundRemoteDll = $null
    foreach ($Path in $RemotePaths) {
        if (Test-Path $Path) { $FoundRemoteDll = $Path; break }
    }
    if ($FoundRemoteDll) {
        Write-Host "DLL localizada em: $FoundRemoteDll" -ForegroundColor DarkGray
        $LocalTempDll = Join-Path $env:TEMP "SrsResources_$([guid]::NewGuid()).dll"
        try {
            Copy-Item -Path $FoundRemoteDll -Destination $LocalTempDll -Force -ErrorAction Stop
            $SrsAssembly = [System.Reflection.Assembly]::LoadFrom($LocalTempDll)
            foreach ($ResourceName in @('SrsResources.errorMessages.resources', 'SrsResources.stateMessages.resources')) {
                $Stream = $SrsAssembly.GetManifestResourceStream($ResourceName)
                if ($Stream) {
                    $Reader = New-Object System.Resources.ResourceReader($Stream)
                    $Reader.GetEnumerator() | ForEach-Object { $ErrorTable[$_.Key] = $_.Value }
                    $Reader.Close()
                }
            }
            Write-Host "Tabela de erros carregada: $($ErrorTable.Count) entradas." -ForegroundColor Green
        } catch {
            Write-Host "Aviso: falha ao carregar DLL: $_" -ForegroundColor Yellow
        }
    } else {
        Write-Host "Aviso: SrsResources.dll nao encontrada em $Server." -ForegroundColor Yellow
    }
    # === P/INVOKE FormatMessage ===
    if (-not ([System.Management.Automation.PSTypeName]'Win32FormatMessage').Type) {
        Add-Type -TypeDefinition @'
    using System;
    using System.Runtime.InteropServices;
    using System.Text;
    public class Win32FormatMessage {
        [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
        private static extern int FormatMessage(uint f, IntPtr s, uint id, uint lang, StringBuilder b, int n, IntPtr a);
        private const uint FROM_SYSTEM     = 0x00001000;
        private const uint IGNORE_INSERTS  = 0x00000200;
        private const uint SUBLANG_DEFAULT = 0x01;
        private const uint LANG_NEUTRAL    = 0x00;
        public static string FromSystem(uint code) {
            var sb = new StringBuilder(2048); // Aumentado para 2048 para evitar truncamento de strings longas
            int len = FormatMessage(FROM_SYSTEM | IGNORE_INSERTS, IntPtr.Zero, code,
                (uint)((SUBLANG_DEFAULT << 10) | LANG_NEUTRAL), sb, sb.Capacity, IntPtr.Zero);
            return len > 0 ? sb.ToString().Trim() : null;
        }
    }
    '@ -Language CSharp
    }
    # === CORES ===
    $CLR_BLACK       = [int](0x00 + 0x00 * 256 + 0x00 * 65536)
    $CLR_HEADER_BG   = [int](0x1F + 0x6B * 256 + 0x31 * 65536)
    $CLR_HEADER_FG   = [int](0xFF + 0xFF * 256 + 0xFF * 65536)
    $CLR_ALT_ROW     = [int](0xE8 + 0xF5 * 256 + 0xE9 * 65536)
    $CLR_SUMM_LABEL  = [int](0xFF + 0x00 * 256 + 0x00 * 65536)
    $CLR_SUMM_VALUE  = [int](0x00 + 0x00 * 256 + 0x00 * 65536)
    $CLR_GENERATED   = [int](0x66 + 0x66 * 256 + 0x66 * 65536)
    $TAB_ERROR       = [int](0xFF + 0x00 * 256 + 0x00 * 65536)
    $TAB_INPROGRESS  = [int](0xFF + 0xA5 * 256 + 0x00 * 65536)
    $TAB_UNKNOWN     = [int](0x80 + 0x80 * 256 + 0x80 * 65536)
    $TAB_COMPLIANT   = [int](0x00 + 0xB0 * 256 + 0x50 * 65536)
    $TAB_DNS         = [int](0x00 + 0x70 * 256 + 0xC0 * 65536)
    $TAB_DNSREMED    = [int](0x00 + 0xB0 * 256 + 0xB0 * 65536)
    $PIE_COMPLIANT   = [int](0x00 + 0xB0 * 256 + 0x50 * 65536)
    $PIE_INPROGRESS  = [int](0xFF + 0xA5 * 256 + 0x00 * 65536)
    $PIE_ERROR       = [int](0xFF + 0x00 * 256 + 0x00 * 65536)
    $PIE_UNKNOWN     = [int](0x80 + 0x80 * 256 + 0x80 * 65536)
    $TabColorMap = @{
        'Error'             = $TAB_ERROR
        'In Progress'       = $TAB_INPROGRESS
        'Unknown'           = $TAB_UNKNOWN
        'Compliant'         = $TAB_COMPLIANT
        'DNS Issues'        = $TAB_DNS
        'DNS Remediation'   = $TAB_DNSREMED
    }
    function Get-DateStamp {
        $IC    = [System.Globalization.CultureInfo]::InvariantCulture
        $Now   = [System.DateTime]::Now
        $Month = $Now.ToString('MMM', $IC)
        $Day   = $Now.Day
        $Hour  = $Now.Hour % 12
        if ($Hour -eq 0) { $Hour = 12 }
        $Min   = $Now.ToString('mm', $IC)
        $AmPm  = if ($Now.Hour -lt 12) { 'am' } else { 'pm' }
        return "$Month-$Day - $($Hour)h$Min$AmPm"
    }
    function Get-SccmOfficialMessage {
        param ([long]$DecimalCode, [hashtable]$ErrorTable)
        $UnsignedVal = [uint32]($DecimalCode -band 0xFFFFFFFFL)
        $Hex         = '0x{0:X8}' -f $UnsignedVal
        $Facility    = ($UnsignedVal -shr 16) -band 0x0FFF
        $Win32Part   = $UnsignedVal -band 0xFFFF
        $SignedKey = [string]([int32][BitConverter]::ToInt32([BitConverter]::GetBytes($UnsignedVal), 0))
        if ($ErrorTable.ContainsKey($SignedKey)) { return $ErrorTable[$SignedKey] }
        if ($Facility -eq 0x007) {
            $Msg = [Win32FormatMessage]::FromSystem($UnsignedVal)
            if ($Msg) { return $Msg }
            $Msg = [Win32FormatMessage]::FromSystem($Win32Part)
            if ($Msg) { return $Msg }
        }
        $Msg = [Win32FormatMessage]::FromSystem($UnsignedVal)
        if ($Msg) { return $Msg }
        $FallbackTable = @{
            '0x87D00202' = 'Software update scan failed.'
            '0x87D0024A' = 'The job is already connected.'
            '0x87D0027C' = 'Software update policy not found.'
            '0x87D00319' = 'Software updates scan cycle is already running.'
            '0x87D00650' = 'Updates handler was unable to continue due to some generic internal error.'
            '0x87D00651' = 'Updates handler job was paused.'
            '0x87D00656' = 'No updates found in the assignment.'
            '0x87D00664' = 'Updates handler job was cancelled.'
            '0x87D00665' = 'Updates handler job failed to run.'
            '0x87D00668' = 'Software update still detected as actionable after apply.'
            '0x87D00692' = 'Software updates installation job timed out.'
            '0x87D00699' = 'Updates handler failed to send notification of the status of the install operation.'
            '0x80246010' = 'The number of round trips to the server exceeded the maximum limit.'
            '0x80240069' = 'WUA: An operation could not be completed because the scan package was invalid.'
            '0x80240438' = 'WUA: A download must be restarted because the update content changed in a new revision.'
            '0x80240439' = 'WUA: A download must be restarted because the location of the source of the download has changed.'
            '0x80240442' = 'WUA: A download manager operation could not be completed because the file digest was not recognized.'
            '0xC80003F3' = 'The Windows Update Agent was stopped while downloading.'
        }
        if ($FallbackTable.ContainsKey($Hex)) { return $FallbackTable[$Hex] }
        return "Unknown Error ($DecimalCode)"
    }

    function Get-InProgressStatus {
        param ($MessageID, [hashtable]$ErrorTable)
     
        if ($null -eq $MessageID) { return 'Unknown' }
     
        $Key = [string][int]$MessageID
     
        if ($ErrorTable -and $ErrorTable.ContainsKey($Key)) {
            return $ErrorTable[$Key]
        }
     
        switch ([int]$MessageID) {
            1 { return 'Downloading update(s)'            }
            2 { return 'Installing update(s)'             }
            4 { return 'Waiting for restart'              }
            5 { return 'Pending system restart'           }
            6 { return 'Downloaded update(s)'             }
            7 { return 'Installing update(s)'             }
            8 { return 'Pending system restart'           }
            9 { return 'Successfully installed update(s)' }
            default { return "Status ID $MessageID"       }
        }
    }

    function Get-UnknownCategory {
        param ($ClientStateDescription)
        if ($null -eq $ClientStateDescription -or $ClientStateDescription -is [System.DBNull]) {
            return 'Client check passed/Unknown'
        }
        switch ($ClientStateDescription) {
            'Active/Pass'      { return 'Client check passed/Active'   }
            'Active/Fail'      { return 'Client check failed/Active'   }
            'Active/Unknown'   { return 'Client check passed/Active'   }
            'Inactive/Pass'    { return 'Client check passed/Inactive' }
            'Inactive/Fail'    { return 'Client check failed/Inactive' }
            'Inactive/Unknown' { return 'Client check passed/Inactive' }
            default            { return "Client check passed/$ClientStateDescription" }
        }
    }
    function Get-DnsCheckData {
        param ([int]$AssignmentID, [string]$ConnectionString, [string[]]$TiposSelecionados, [string]$DomainSuffix)
        $EmptyResult = [PSCustomObject]@{
            Issues         = (New-Object System.Collections.Generic.List[Object])
            IssueTargets   = (New-Object System.Collections.Generic.List[Object])
            TotalChecked   = 0
            TotalOk        = 0
            TotalOffline   = 0
        }
        $Conds = @()
        if ($TiposSelecionados -contains 'Error')       { $Conds += '(uas.IsCompliant = 0 AND uas.LastEnforcementErrorCode IS NOT NULL AND uas.LastEnforcementErrorCode <> 0)' }
        if ($TiposSelecionados -contains 'In Progress') { $Conds += '(uas.IsCompliant = 0 AND (uas.LastEnforcementErrorCode IS NULL OR uas.LastEnforcementErrorCode = 0))' }
        if ($TiposSelecionados -contains 'Unknown')     { $Conds += '(uas.IsCompliant IS NULL)' }
        if ($Conds.Count -eq 0) { return $EmptyResult }
        $WhereStatus = $Conds -join ' OR '
        $Query = @"
    SELECT DISTINCT
        r.ResourceID        AS ResourceID,
        r.Name0             AS DeviceName,
        r.Full_Domain_Name0 AS DomainName,
        uas.LastEnforcementMessageID AS LastEnforcementMessageID,
        CASE
            WHEN uas.IsCompliant IS NULL THEN 'Unknown'
            WHEN uas.LastEnforcementErrorCode IS NOT NULL AND uas.LastEnforcementErrorCode <> 0 THEN 'Error'
            ELSE 'In Progress'
        END                 AS StatusCategory
    FROM v_UpdateAssignmentStatus uas
    JOIN v_R_System r ON uas.ResourceID = r.ResourceID
    WHERE uas.AssignmentID = $AssignmentID
      AND ($WhereStatus)
    ORDER BY r.Name0
    "@
        $Conn    = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
        $Cmd     = New-Object System.Data.SqlClient.SqlCommand($Query, $Conn)
        $Adapter = New-Object System.Data.SqlClient.SqlDataAdapter($Cmd)
        $Table   = New-Object System.Data.DataTable
        try {
            $Conn.Open()
            $Adapter.Fill($Table) | Out-Null
            $Conn.Close()
        } catch {
            if ($Conn.State -eq 'Open') { $Conn.Close() }
            Write-Host "Aviso: falha ao buscar dispositivos para DNS check: $_" -ForegroundColor Yellow
            return $EmptyResult
        }
        $DomainPattern = [regex]::Escape($DomainSuffix) + '$'
        $Items = New-Object System.Collections.Generic.List[Object]
        foreach ($Row in $Table) {
            $Device     = [string]$Row.DeviceName
            $FullDomain = if ($Row.DomainName -is [System.DBNull] -or [string]::IsNullOrWhiteSpace([string]$Row.DomainName)) { '' } else { [string]$Row.DomainName }
            $Fqdn       = if ($FullDomain) { "$Device.$FullDomain" } else { $Device }
            $Item = [PSCustomObject]@{
                ResourceID     = if ($Row.ResourceID -is [System.DBNull]) { $null } else { [int]$Row.ResourceID }
                Device         = $Device
                DomainStripped = ($FullDomain -replace $DomainPattern, '')
                Fqdn           = $Fqdn
                StatusCategory = [string]$Row.StatusCategory
                MessageID      = if ($Row.LastEnforcementMessageID -is [System.DBNull]) { $null } else { [int]$Row.LastEnforcementMessageID }
                TaskHost       = $null
                TaskFqdn       = $null
                TaskReverse    = $null
                TaskPing       = $null
                IPHostname     = $null
                IPFqdn         = $null
                ReverseName    = ''
                PingStatus     = 'Unknown'
            }
            try { $Item.TaskHost = [System.Net.Dns]::GetHostAddressesAsync($Device) } catch { }
            try { $Item.TaskFqdn = [System.Net.Dns]::GetHostAddressesAsync($Fqdn)   } catch { }
            try {
                $PingSender = New-Object System.Net.NetworkInformation.Ping
                $Item.TaskPing = $PingSender.SendPingAsync($Device, 1200)
            } catch { }
            $Items.Add($Item)
        }
        foreach ($Item in $Items) {
            if ($Item.TaskPing) {
                try {
                    if ($Item.TaskPing.Wait(1500)) {
                        $Item.PingStatus = if ($Item.TaskPing.Result.Status -eq 'Success') { 'Online' } else { 'Offline' }
                    } else { $Item.PingStatus = 'Offline' }
                } catch { $Item.PingStatus = 'Offline' }
            } else { $Item.PingStatus = 'Offline' }
            $Item.IPHostname = Get-FirstIPv4 -Task $Item.TaskHost
            $Item.IPFqdn     = Get-FirstIPv4 -Task $Item.TaskFqdn
            $RefIP = if ($Item.IPFqdn) { $Item.IPFqdn } elseif ($Item.IPHostname) { $Item.IPHostname } else { $null }
            if ($RefIP -and $Item.PingStatus -eq 'Online') {
                try { $Item.TaskReverse = [System.Net.Dns]::GetHostEntryAsync($RefIP) } catch { }
            }
        }
        $Issues         = New-Object System.Collections.Generic.List[Object]
        $IssueTargets   = New-Object System.Collections.Generic.List[Object]
        $TotalOk        = 0
        $TotalOffline   = 0
        foreach ($Item in $Items) {
            if ($Item.PingStatus -eq 'Offline') {
                $TotalOffline++
                continue
            }
            if ($Item.TaskReverse) {
                try {
                    if ($Item.TaskReverse.Wait(2000)) { $Item.ReverseName = $Item.TaskReverse.Result.HostName }
                } catch { }
            }
            $Rev = ($Item.ReverseName -replace '\.$', '')
            $DnsStatus = if (-not $Item.IPHostname -and -not $Item.IPFqdn) {
                'No DNS Record'
            } elseif ($Item.IPHostname -and $Item.IPFqdn -and $Item.IPHostname -ne $Item.IPFqdn) {
                'IP Mismatch (Hostname x FQDN)'
            } elseif (-not $Item.IPFqdn) {
                'FQDN Not Resolved'
            } elseif (-not $Item.IPHostname) {
                'Hostname Not Resolved (FQDN OK)'
            } elseif (-not $Rev) {
                'Reverse (PTR) Lookup Failed'
            } elseif ($Rev -eq $Item.Fqdn -or $Rev -eq $Item.Device) {
                'OK'
            } else {
                'Reverse (PTR) Mismatch'
            }
            if ($DnsStatus -eq 'OK') {
                $TotalOk++
                continue
            }
            $Issues.Add([PSCustomObject][ordered]@{
                DeviceName         = $Item.Device
                'Domain (as SCCM)' = $Item.DomainStripped
                StatusCategory     = $Item.StatusCategory
                IPHostname         = if ($Item.IPHostname) { $Item.IPHostname } else { '' }
                IPFqdn             = if ($Item.IPFqdn)     { $Item.IPFqdn }     else { '' }
                ReverseDnsName     = $Rev
                DnsStatus          = $DnsStatus
            }) | Out-Null
            $IssueTargets.Add([PSCustomObject]@{
                Device          = $Item.Device
                Fqdn            = $Item.Fqdn
                DomainStripped  = $Item.DomainStripped
                DnsStatusBefore = $DnsStatus
            }) | Out-Null
        }
        return [PSCustomObject]@{
            Issues         = $Issues
            IssueTargets   = $IssueTargets
            TotalChecked   = $Items.Count
            TotalOk        = $TotalOk
            TotalOffline   = $TotalOffline
        }
    }
    function Get-FirstIPv4 {
        param ($Task, [int]$TimeoutMs = 4000)
        if ($null -eq $Task) { return $null }
        try {
            if (-not $Task.Wait($TimeoutMs)) { return $null }
            foreach ($Addr in $Task.Result) {
                if ($Addr.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork) {
                    return $Addr.IPAddressToString
                }
            }
        } catch { }
        return $null
    }
    function Test-DnsBatch {
        param ($Targets)
        $Items = New-Object System.Collections.Generic.List[Object]
        foreach ($T in $Targets) {
            $Item = [PSCustomObject]@{
                Device      = $T.Device
                Fqdn        = $T.Fqdn
                TaskHost    = $null
                TaskFqdn    = $null
                TaskReverse = $null
                IPHostname  = $null
                IPFqdn      = $null
                ReverseName = ''
            }
            try { $Item.TaskHost = [System.Net.Dns]::GetHostAddressesAsync($T.Device) } catch { }
            try { $Item.TaskFqdn = [System.Net.Dns]::GetHostAddressesAsync($T.Fqdn)   } catch { }
            $Items.Add($Item)
        }
        foreach ($Item in $Items) {
            $Item.IPHostname = Get-FirstIPv4 -Task $Item.TaskHost
            $Item.IPFqdn     = Get-FirstIPv4 -Task $Item.TaskFqdn
            $RefIP = if ($Item.IPFqdn) { $Item.IPFqdn } elseif ($Item.IPHostname) { $Item.IPHostname } else { $null }
            if ($RefIP) {
                try { $Item.TaskReverse = [System.Net.Dns]::GetHostEntryAsync($RefIP) } catch { }
            }
        }
        $Map = @{}
        foreach ($Item in $Items) {
            if ($Item.TaskReverse) {
                try {
                    if ($Item.TaskReverse.Wait(4000)) { $Item.ReverseName = $Item.TaskReverse.Result.HostName }
                } catch { }
            }
            $Rev = ($Item.ReverseName -replace '\.$', '')
            $DnsStatus = if (-not $Item.IPHostname -and -not $Item.IPFqdn) {
                'No DNS Record'
            } elseif ($Item.IPHostname -and $Item.IPFqdn -and $Item.IPHostname -ne $Item.IPFqdn) {
                'IP Mismatch (Hostname x FQDN)'
            } elseif (-not $Item.IPFqdn) {
                'FQDN Not Resolved'
            } elseif (-not $Item.IPHostname) {
                'Hostname Not Resolved (FQDN OK)'
            } elseif (-not $Rev) {
                'Reverse (PTR) Lookup Failed'
            } elseif ($Rev -eq $Item.Fqdn -or $Rev -eq $Item.Device) {
                'OK'
            } else {
                'Reverse (PTR) Mismatch'
            }
            $Map[$Item.Device] = $DnsStatus
        }
        return $Map
    }
    function Invoke-DnsRemediation {
        param ($IssueTargets)
        $DeviceNames = @($IssueTargets | ForEach-Object { $_.Device })
        Write-Host "  >> Executando flushdns + registerdns em $($DeviceNames.Count) maquina(s) via WinRM..." -ForegroundColor DarkCyan
        $Succeeded = @{}
        try {
            $Output = Invoke-Command -ComputerName $DeviceNames -ScriptBlock {
                ipconfig /flushdns    | Out-Null
                ipconfig /registerdns | Out-Null
                'OK'
            } -ThrottleLimit 32 -ErrorAction SilentlyContinue
            foreach ($O in $Output) {
                if ($O.PSComputerName) { $Succeeded[$O.PSComputerName.ToUpper()] = $true }
            }
        } catch {
            Write-Host "    Aviso: falha geral no Invoke-Command: $_" -ForegroundColor Yellow
        }
        $FailCount = $DeviceNames.Count - $Succeeded.Count
        Write-Host "    $($Succeeded.Count) remediada(s) | $FailCount sem acesso WinRM" -ForegroundColor DarkGray
        Write-Host "  >> Aguardando 30s para propagacao do registro DNS..." -ForegroundColor DarkCyan
        Start-Sleep -Seconds 30
        try { Clear-DnsClientCache -ErrorAction Stop } catch { ipconfig /flushdns | Out-Null }
        Write-Host "  >> Reverificando DNS das maquinas tratadas..." -ForegroundColor DarkCyan
        $AfterMap = Test-DnsBatch -Targets $IssueTargets
        $ResultList = New-Object System.Collections.Generic.List[Object]
        $FixedCount = 0
        foreach ($T in $IssueTargets) {
            $Remediation = if ($Succeeded.ContainsKey($T.Device.ToUpper())) { 'Success' } else { 'WinRM Failed' }
            $After       = if ($AfterMap.ContainsKey($T.Device)) { $AfterMap[$T.Device] } else { 'Not Rechecked' }
            $Fixed       = if ($After -eq 'OK') { 'Yes' } else { 'No' }
            if ($Fixed -eq 'Yes') { $FixedCount++ }
            $ResultList.Add([PSCustomObject][ordered]@{
                DeviceName         = $T.Device
                'Domain (as SCCM)' = $T.DomainStripped
                DnsStatusBefore    = $T.DnsStatusBefore
                Remediation        = $Remediation
                DnsStatusAfter     = $After
                Fixed              = $Fixed
            }) | Out-Null
        }
        Write-Host "    Resultado: $FixedCount de $($IssueTargets.Count) maquina(s) com DNS OK apos remediacao" -ForegroundColor DarkGray
        return $ResultList
    }
    function Get-CollectionTotal {
        param ([int]$AssignmentID, [string]$ConnectionString)
        $Query = "SELECT COUNT(DISTINCT ResourceID) AS Total FROM v_UpdateAssignmentStatus WHERE AssignmentID = $AssignmentID"
        $Conn = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
        $Cmd  = New-Object System.Data.SqlClient.SqlCommand($Query, $Conn)
        try {
            $Conn.Open()
            $Total = [int]$Cmd.ExecuteScalar()
            $Conn.Close()
            return $Total
        } catch {
            if ($Conn.State -eq 'Open') { $Conn.Close() }
            Write-Host "Aviso: falha ao buscar total da collection: $_" -ForegroundColor Yellow
            return 0
        }
    }
    function Get-DeviceUserName {
        param ([string]$DeviceName, [string]$ConnectionString)
        $Escaped = $DeviceName -replace "'", "''"
        $Query   = "SELECT TOP 1 User_Name0 FROM v_R_System WHERE Name0 = '$Escaped'"
        $Conn = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
        $Cmd  = New-Object System.Data.SqlClient.SqlCommand($Query, $Conn)
        try {
            $Conn.Open()
            $Result = $Cmd.ExecuteScalar()
            $Conn.Close()
            if ($null -eq $Result -or $Result -is [System.DBNull]) { return $null }
            $u = [string]$Result
            if ($u -match '\') { $u = $u.Split('\\')[-1] }
            if ([string]::IsNullOrWhiteSpace($u)) { return $null }
            return $u
        } catch {
            if ($Conn.State -eq 'Open') { $Conn.Close() }
            return $null
        }
    }
    function Get-AdUserInfo {
        param ([string]$SamAccountName)
        try {
            $Searcher = New-Object System.DirectoryServices.DirectorySearcher
            $Searcher.Filter = "(&(objectClass=user)(sAMAccountName=$SamAccountName))"
            $Searcher.PropertiesToLoad.Add("mail")      | Out-Null
            $Searcher.PropertiesToLoad.Add("givenName") | Out-Null
            $Result = $Searcher.FindOne()
            if (-not $Result) { return $null }
            $Email = if ($Result.Properties["mail"].Count -gt 0)      { [string]$Result.Properties["mail"][0] }      else { '' }
            $Given = if ($Result.Properties["givenName"].Count -gt 0) { [string]$Result.Properties["givenName"][0] } else { '' }
            return [PSCustomObject]@{
                Email     = $Email
                GivenName = $Given
            }
        } catch {
            return $null
        }
    }
    function Send-PendingRestartReminders {
        param (
            [object[]]$Devices,
            [string]$ConnectionString,
            [string]$SmtpServer  = '://pseg.com',
            [string]$FromAddress = 'servicemywiz_email@pseg.com',
            [string]$CcAddress   = 'felipe.picone@pseg.com'
        )
        $Sent          = 0
        $NoUser        = 0
        $NoEmail       = 0
        $FailSend      = 0
        $SkippedManual = 0
        $Aborted       = $false
        Write-Host ""
        Write-Host "  >> Buscando usuarios e enviando emails para $($Devices.Count) maquina(s)..." -ForegroundColor DarkCyan
        if ($CcAddress) {
            Write-Host "  >> Cc: $CcAddress" -ForegroundColor DarkCyan
        }
        Write-Host "  >> Modo confirmacao manual: S=enviar, N=pular, A=abortar todos" -ForegroundColor DarkCyan
        foreach ($Dev in $Devices) {
            if ($Aborted) { break }
            $DeviceName = [string]$Dev.DeviceName
            $UserName   = Get-DeviceUserName -DeviceName $DeviceName -ConnectionString $ConnectionString
            if ([string]::IsNullOrWhiteSpace($UserName)) {
                Write-Host "    [SKIP] $DeviceName : nenhum usuario associado em v_R_System" -ForegroundColor Yellow
                $NoUser++
                continue
            }
            $AdUser = Get-AdUserInfo -SamAccountName $UserName
            if ($null -eq $AdUser -or [string]::IsNullOrWhiteSpace($AdUser.Email)) {
                Write-Host "    [SKIP] $DeviceName ($UserName) : email nao encontrado no AD" -ForegroundColor Yellow
                $NoEmail++
                continue
            }
            $Given = if ([string]::IsNullOrWhiteSpace($AdUser.GivenName)) { $UserName } else { $AdUser.GivenName }
            Write-Host ""
            Write-Host "    Device : $DeviceName"            -ForegroundColor Cyan
            Write-Host "    User   : $UserName"              -ForegroundColor Cyan
            Write-Host "    Nome   : $Given"                 -ForegroundColor Cyan
            Write-Host "    Email  : $($AdUser.Email)"       -ForegroundColor Cyan
            if ($CcAddress) { Write-Host "    Cc     : $CcAddress" -ForegroundColor Cyan }
            $Resp = Read-Host "    Enviar este email? (S/N/A)"
            if ($Resp -match '^[Aa]') {
                Write-Host "    >> Envio abortado pelo usuario. Saindo do loop." -ForegroundColor Yellow
                $Aborted = $true
                break
            }
            if ($Resp -notmatch '^[SsYy]') {
                Write-Host "    [SKIP] $DeviceName : pulado manualmente" -ForegroundColor DarkGray
                $SkippedManual++
                continue
            }
            $Body = @"
    Dear $Given,
    Your device $DeviceName has a pending system restart to complete the latest updates. Please reboot your device at your earliest convenience.
    Regards,
    PSEG IT Team
    "@
            $MailParams = @{
                SmtpServer  = $SmtpServer
                From        = $FromAddress
                To          = $AdUser.Email
                Subject     = "$Given, please reboot your device ($DeviceName)"
                Body        = $Body
                ErrorAction = 'Stop'
            }
            if ($CcAddress) { $MailParams.Cc = $CcAddress }
            try {
                Send-MailMessage @MailParams
                Write-Host "    [OK]   $DeviceName -> $Given <$($AdUser.Email)>" -ForegroundColor Green
                $Sent++
            } catch {
                Write-Host "    [FAIL] $DeviceName ($UserName) : $_" -ForegroundColor Red
                $FailSend++
            }
        }
        Write-Host ""
        Write-Host "  Resultado: $Sent enviado(s) | $NoUser sem usuario | $NoEmail sem email no AD | $FailSend falha(s) de envio | $SkippedManual pulado(s) manualmente" -ForegroundColor Cyan
    }
    function Get-ReportData {
        param ([string]$Tipo, [int]$AssignmentID, [string]$ConnectionString, [hashtable]$ErrorTable, [string]$DomainSuffix)
        $WhereExtra = switch ($Tipo) {
            'Error'       { 'AND uas.IsCompliant = 0 AND uas.LastEnforcementErrorCode IS NOT NULL AND uas.LastEnforcementErrorCode <> 0' }
            'In Progress' { 'AND uas.IsCompliant = 0 AND (uas.LastEnforcementErrorCode IS NULL OR uas.LastEnforcementErrorCode = 0)' }
            'Unknown'     { 'AND uas.IsCompliant IS NULL' }
            'Compliant'   { 'AND uas.IsCompliant = 1' }
        }
        $Query = @"
    SELECT
        r.ResourceID                     AS ResourceID,
        r.Name0                          AS DeviceName,
        r.Full_Domain_Name0              AS DomainName,
        uas.LastEnforcementErrorCode     AS LastEnforcementErrorCode,
        uas.LastEnforcementMessageID     AS LastEnforcementMessageID,
        uas.LastEnforcementMessageTime   AS LastEnforcementMessageTime,
        ch.LastActiveTime                AS LastActivity,
        ch.ClientStateDescription        AS ClientStateDescription
    FROM v_UpdateAssignmentStatus uas
    JOIN v_R_System r               ON uas.ResourceID = r.ResourceID
    LEFT JOIN v_CH_ClientSummary ch ON uas.ResourceID = ch.ResourceID
    WHERE uas.AssignmentID = $AssignmentID
    $WhereExtra
    "@
        $Conn    = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
        $Cmd     = New-Object System.Data.SqlClient.SqlCommand($Query, $Conn)
        $Adapter = New-Object System.Data.SqlClient.SqlDataAdapter($Cmd)
        $Table   = New-Object System.Data.DataTable
        try {
            $Conn.Open()
            $Adapter.Fill($Table) | Out-Null
            $Conn.Close()
        } catch {
            if ($Conn.State -eq 'Open') { $Conn.Close() }
            throw $_
        }
        $DomainPattern = [regex]::Escape($DomainSuffix) + '$'
        $DoPing        = $Tipo -in @('Error', 'In Progress', 'Unknown')
        $Tasks         = New-Object System.Collections.Generic.List[Object]
        foreach ($Row in $Table) {
            $Task = [PSCustomObject]@{
                ResourceID               = if ($Row.ResourceID -is [System.DBNull]) { $null } else { [int]$Row.ResourceID }
                Device                   = $Row.DeviceName
                Domain                   = ($Row.DomainName -replace $DomainPattern, '')
                ErrorCode                = if ($Row.LastEnforcementErrorCode   -is [System.DBNull]) { $null } else { $Row.LastEnforcementErrorCode }
                LastEnforcementMessageID = if ($Row.LastEnforcementMessageID   -is [System.DBNull]) { $null } else { $Row.LastEnforcementMessageID }
                LastEnforcementTime = if ($Row.LastEnforcementMessageTime -is [System.DBNull]) { $null } else { [System.TimeZoneInfo]::ConvertTimeFromUtc([datetime]$Row.LastEnforcementMessageTime, [System.TimeZoneInfo]::Local) }
                LastActivity             = if ($Row.LastActivity               -is [System.DBNull]) { $null } else { $Row.LastActivity }
                ClientStateDescription   = if ($Row.ClientStateDescription     -is [System.DBNull]) { $null } else { $Row.ClientStateDescription }
                PingAsync                = $null
            }
            if ($DoPing) {
                $PingSender     = New-Object System.Net.NetworkInformation.Ping
                $Task.PingAsync = $PingSender.SendPingAsync($Row.DeviceName, 1200)
            }
            $Tasks.Add($Task)
        }
        $ResultList = New-Object System.Collections.Generic.List[Object]
        foreach ($Task in $Tasks) {
            $PingStatus = 'N/A'
            if ($DoPing -and $Task.PingAsync) {
                try {
                    $Reply      = $Task.PingAsync.Result
                    $PingStatus = if ($Reply.Status -eq 'Success') { 'Online' } else { 'Offline' }
                } catch { $PingStatus = 'Offline' }
            }
            $HexCode  = ''
            $Traducao = ''
            if ($null -ne $Task.ErrorCode -and $Task.ErrorCode -ne 0) {
                $UnsignedVal = [uint32]([long]$Task.ErrorCode -band 0xFFFFFFFFL)
                $HexCode     = '0x{0:X8}' -f $UnsignedVal
                $Traducao    = Get-SccmOfficialMessage -DecimalCode ([long]$Task.ErrorCode) -ErrorTable $ErrorTable
            }
            $ResultObj = [ordered]@{
                DeviceName          = $Task.Device
                'Domain (as SCCM)'  = $Task.Domain
                LastActivity        = $Task.LastActivity
                LastEnforcementTime = $Task.LastEnforcementTime
            }
            if ($Tipo -eq 'In Progress') { $ResultObj['Status'] = Get-InProgressStatus -MessageID $Task.LastEnforcementMessageID -ErrorTable $ErrorTable }
            if ($Tipo -eq 'Unknown')     { $ResultObj['Category']           = Get-UnknownCategory -ClientStateDescription $Task.ClientStateDescription }
            if ($DoPing)                 { $ResultObj['StatusDoPing']       = $PingStatus }
            if ($Tipo -eq 'Error')       { $ResultObj['ErrorCodeHex']       = $HexCode    }
            if ($Tipo -eq 'Error')       { $ResultObj['TraducaoNativaDoSO'] = $Traducao   }
            [void]$ResultList.Add([PSCustomObject]$ResultObj)
        }
        return $ResultList
    }
    function Write-DataSheet {
        param ($Sheet, $Data, $TabColor, $SummarizationTime, $GeneratedAt)
        $Sheet.Tab.Color = $TabColor
        $ColCount        = if ($Data -and $Data.Count -gt 0) { $Data[0].PSObject.Properties.Name.Count } else { 1 }
        if ($SummarizationTime) {
            $Cell           = $Sheet.Cells.Item(1, 1)
            $Cell.Font.Bold = $true
            $Cell.Font.Size = 11
            if ($ColCount -gt 1) {
                $Sheet.Range($Sheet.Cells.Item(1, 1), $Sheet.Cells.Item(1, $ColCount)).Merge() | Out-Null
            }
            $Label       = 'Last Summarization: '
            $Cell.Value2 = "$Label$SummarizationTime"
            $Cell.Characters(1, $Label.Length).Font.Color                              = $script:CLR_SUMM_LABEL
            $Cell.Characters(1, $Label.Length).Font.Bold                               = $true
            $Cell.Characters($Label.Length + 1, $SummarizationTime.Length).Font.Color  = $script:CLR_SUMM_VALUE
            $Cell.Characters($Label.Length + 1, $SummarizationTime.Length).Font.Bold   = $false
        }
        $GenCell             = $Sheet.Cells.Item(2, 1)
        $GenCell.Value2      = "Report generated at: $GeneratedAt"
        $GenCell.Font.Italic = $true
        $GenCell.Font.Color  = $script:CLR_GENERATED
        if ($ColCount -gt 1) {
            $Sheet.Range($Sheet.Cells.Item(2, 1), $Sheet.Cells.Item(2, $ColCount)).Merge() | Out-Null
        }
        $HeaderRow = 3
        if (-not $Data -or $Data.Count -eq 0) {
            $Sheet.Cells.Item($HeaderRow, 1).Value2 = 'Nenhum dispositivo encontrado.'
            return
        }
        $Columns  = $Data[0].PSObject.Properties.Name
        $ColCount = $Columns.Count
        for ($c = 0; $c -lt $ColCount; $c++) {
            $Cell                = $Sheet.Cells.Item($HeaderRow, $c + 1)
            $Cell.Value2         = $Columns[$c]
            $Cell.Font.Bold      = $true
            $Cell.Interior.Color = $script:CLR_HEADER_BG
            $Cell.Font.Color     = $script:CLR_HEADER_FG
        }
        $SheetName = $Sheet.Name
        for ($r = 0; $r -lt $Data.Count; $r++) {
            if ($r % 50 -eq 0 -or $r -eq $Data.Count - 1) {
                $Pct = [int](($r + 1) / $Data.Count * 100)
                Write-Progress -Activity "Exportando aba: $SheetName" \`
                               -Status "Linha $($r + 1) de $($Data.Count) ($Pct%)" \`
                               -PercentComplete $Pct
            }
            for ($c = 0; $c -lt $ColCount; $c++) {
                $Val = $Data[$r].($Columns[$c])
                $Sheet.Cells.Item($HeaderRow + $r + 1, $c + 1).Value2 = if ($null -ne $Val) { "$Val" } else { '' }
            }
            if ($r % 2 -eq 1) {
                $Sheet.Rows.Item($HeaderRow + $r + 1).Interior.Color = $script:CLR_ALT_ROW
            }
        }
        Write-Progress -Activity "Exportando aba: $SheetName" -Completed
        $Sheet.UsedRange.Columns.AutoFit() | Out-Null
        for ($c = 1; $c -le $ColCount; $c++) {
            if ($Sheet.Cells.Item($HeaderRow, $c).Value2 -eq "TraducaoNativaDoSO") {
                if ($Sheet.Columns.Item($c).ColumnWidth -gt 40) {
                    $Sheet.Columns.Item($c).ColumnWidth = 40
                }
                break
            }
        }
        $Sheet.Range($Sheet.Cells.Item($HeaderRow, 1), $Sheet.Cells.Item($HeaderRow, $ColCount)).AutoFilter() | Out-Null
        $Sheet.Application.ActiveWindow.SplitRow    = $HeaderRow
        $Sheet.Application.ActiveWindow.FreezePanes = $true
    }
    function Add-ClassificationChart {
        param (
            $Sheet,
            $Data,
            [string]$CategoryField,
            [string]$DescriptionField = '',
            [string]$ChartType,            # 'Bar' ou 'Pie'
            [string]$ChartTitle,
            [bool]$GroupSmallSlices = $true,
            [int]$HeaderRow = 3
        )
        if (-not $Data -or $Data.Count -eq 0) { return }
        $Step = 'init'
        try {
            $DataColumnCount = [int]$Data[0].PSObject.Properties.Name.Count
            $Total           = [int]$Data.Count
            $Step = 'group'
            $Groups = @($Data | Group-Object -Property $CategoryField | Sort-Object -Property Count -Descending)
            $Step = 'classify'
            [string[]]$Labels = @()
            [int[]]$Counts    = @()
            $OthersCount = 0
            foreach ($G in $Groups) {
                $RawKey = if ($null -eq $G.Name -or [string]::IsNullOrWhiteSpace([string]$G.Name)) { '(empty)' } else { [string]$G.Name }
                $Cnt    = [int]$G.Count
                $Pct    = [double]$Cnt / [double]$Total
                if ($GroupSmallSlices -and $Pct -lt 0.01) {
                    $OthersCount += $Cnt
                    continue
                }
                if ($ChartType -eq 'Bar' -and -not [string]::IsNullOrEmpty($DescriptionField)) {
                    $DescVal = ($G.Group | Select-Object -First 1).($DescriptionField)
                    if ([string]::IsNullOrWhiteSpace([string]$DescVal)) {
                        $Label = $RawKey
                    } else {
                        $DescStr = [string]$DescVal
                        if ($DescStr.Length -gt 50) { $DescStr = $DescStr.Substring(0, 47) + '...' }
                        $Label = "$RawKey - $DescStr"
                    }
                } else {
                    $Label = $RawKey
                }
                $Labels += [string]$Label
                $Counts += [int]$Cnt
            }
            if ($OthersCount -gt 0) {
                $Labels += 'Other'
                $Counts += [int]$OthersCount
            }
            if ($Labels.Length -eq 0) { return }
            $Step = 'sort'
            if ($ChartType -eq 'Bar') {
                $Pairs = for ($i = 0; $i -lt $Labels.Length; $i++) {
                    [PSCustomObject]@{ L = [string]$Labels[$i]; C = [int]$Counts[$i] }
                }
                $Sorted = @($Pairs | Sort-Object -Property C)
                [string[]]$NewLabels = @()
                [int[]]$NewCounts    = @()
                foreach ($P in $Sorted) {
                    $NewLabels += [string]$P.L
                    $NewCounts += [int]$P.C
                }
                $Labels = $NewLabels
                $Counts = $NewCounts
            }
            $ItemCount = [int]$Labels.Length
            $Step = 'write-aux-cells'
            $AuxCol = [int]50
            $Sheet.Cells.Item([int]$HeaderRow, $AuxCol).Value2       = 'Category'
            $Sheet.Cells.Item($HeaderRow, [int]($AuxCol + 1)).Value2 = 'Count'
            for ($i = 0; $i -lt $ItemCount; $i++) {
                $RowIdx = [int]($HeaderRow + $i + 1)
                $Sheet.Cells.Item($RowIdx, $AuxCol).Value2           = [string]$Labels[$i]
                $Sheet.Cells.Item($RowIdx, [int]($AuxCol + 1)).Value2 = [double]$Counts[$i]
            }
            $Step = 'hide-aux-cols'
            $Sheet.Columns.Item($AuxCol).Hidden           = $true
            $Sheet.Columns.Item([int]($AuxCol + 1)).Hidden = $true
            $Step = 'position'
            $ChartCol    = [int]($DataColumnCount + 2)
            $ChartLeft   = [double]($Sheet.Cells.Item(1, $ChartCol).Left)
            $ChartTop    = [double]0
            $ChartWidth  = [double]460
            if ($ChartType -eq 'Bar') {
                $H = ($ItemCount * 22) + 100
                if ($H -gt 800) { $H = 800 }
                if ($H -lt 360) { $H = 360 }
                $ChartHeight = [double]$H
            } else {
                $ChartHeight = [double]360
            }
            $Step = 'create-chart'
            $ChartObj = $Sheet.ChartObjects().Add($ChartLeft, $ChartTop, $ChartWidth, $ChartHeight)
            $Chart    = $ChartObj.Chart
            $Step = 'source-data'
            $ChartRange = $Sheet.Range(
                $Sheet.Cells.Item([int]$HeaderRow, $AuxCol),
                $Sheet.Cells.Item([int]($HeaderRow + $ItemCount), [int]($AuxCol + 1))
            )
            if ($ChartType -eq 'Bar') {
                $Chart.ChartType = [int]57
            } else {
                $Chart.ChartType = [int]5
            }
            $Chart.SetSourceData($ChartRange)
            $Chart.PlotVisibleOnly = $false
            $Step = 'title'
            $Chart.HasTitle             = $true
            $Chart.ChartTitle.Text      = [string]$ChartTitle
            $Chart.ChartTitle.Font.Size = 14
            $Chart.ChartTitle.Font.Bold = $true
            $Step = 'series-config'
            $Chart.SeriesCollection(1).HasDataLabels = $true
            if ($ChartType -eq 'Bar') {
                $DL = $Chart.SeriesCollection(1).DataLabels()
                $DL.ShowValue = $true
                $DL.Font.Size = 9
                $Chart.SeriesCollection(1).Format.Fill.ForeColor.RGB = [int]$script:TAB_ERROR
                $Chart.HasLegend = $false
                try { $Chart.Axes(1).TickLabels.Font.Size = 9 } catch { }
                try { $Chart.Axes(2).TickLabels.Font.Size = 9 } catch { }
            } else {
                $DL = $Chart.SeriesCollection(1).DataLabels()
                $DL.ShowPercentage = $true
                $DL.ShowValue      = $true
                $DL.Separator      = "\`n"
                $DL.Font.Size      = 9
                try { $DL.ShowLeaderLines = $true } catch { }
                $Chart.HasLegend        = $true
                $Chart.Legend.Position  = -4107
                $Chart.Legend.Font.Size = 10
            }
        } catch {
            $SheetName = try { [string]$Sheet.Name } catch { '?' }
            Write-Host "" -ForegroundColor Red
            Write-Host "  >> Add-ClassificationChart FALHOU" -ForegroundColor Red
            Write-Host "     Sheet     : $SheetName" -ForegroundColor Red
            Write-Host "     ChartType : $ChartType" -ForegroundColor Red
            Write-Host "     Etapa     : $Step" -ForegroundColor Red
            Write-Host "     Mensagem  : $($_.Exception.Message)" -ForegroundColor Red
            throw
        }
    }
    function Export-XlsxMultiSheet {
        param ([hashtable]$Sheets, [hashtable]$SheetTimes, [string[]]$TiposSelecionados, [bool]$IncluirSummary, [bool]$IncluirDns, [bool]$IncluirDnsRemediation, [int]$TotalCollection, [string]$Path, [string]$SummarizationTime = '', [string]$DeploymentName = '', [string]$GeneratedAt = '')
        $Excel                = New-Object -ComObject Excel.Application
        $Excel.Visible        = $false
        $Excel.DisplayAlerts  = $false
        $Excel.ScreenUpdating = $false
        $Workbook = $Excel.Workbooks.Add()
        while ($Workbook.Worksheets.Count -gt 1) {
            $Workbook.Worksheets.Item($Workbook.Worksheets.Count).Delete()
        }
        $FirstSheet = $true
        foreach ($Tipo in $TiposSelecionados) {
            if ($FirstSheet) {
                $Sheet      = $Workbook.Worksheets.Item(1)
                $Sheet.Name = $Tipo
                $FirstSheet = $false
            } else {
                $Sheet      = $Workbook.Worksheets.Add([System.Reflection.Missing]::Value, $Workbook.Worksheets.Item($Workbook.Worksheets.Count))
                $Sheet.Name = $Tipo
            }
            Write-DataSheet -Sheet $Sheet -Data $Sheets[$Tipo] -TabColor $script:TabColorMap[$Tipo] -SummarizationTime $SummarizationTime -GeneratedAt $SheetTimes[$Tipo]
            switch ($Tipo) {
                'Error'       { Add-ClassificationChart -Sheet $Sheet -Data $Sheets[$Tipo] -CategoryField 'ErrorCodeHex' -DescriptionField 'TraducaoNativaDoSO' -ChartType 'Bar' -ChartTitle 'Errors by Code'         -GroupSmallSlices $false }
                'In Progress' { Add-ClassificationChart -Sheet $Sheet -Data $Sheets[$Tipo] -CategoryField 'Status'                                              -ChartType 'Pie' -ChartTitle 'In Progress by Status'  -GroupSmallSlices $true  }
                'Unknown'     { Add-ClassificationChart -Sheet $Sheet -Data $Sheets[$Tipo] -CategoryField 'Category'                                            -ChartType 'Pie' -ChartTitle 'Unknown by Category'    -GroupSmallSlices $true  }
            }
        }
        if ($IncluirDns) {
            $DnsSheet      = $Workbook.Worksheets.Add([System.Reflection.Missing]::Value, $Workbook.Worksheets.Item($Workbook.Worksheets.Count))
            $DnsSheet.Name = 'DNS Issues'
            Write-DataSheet -Sheet $DnsSheet -Data $Sheets['DNS Issues'] -TabColor $script:TabColorMap['DNS Issues'] -SummarizationTime $SummarizationTime -GeneratedAt $SheetTimes['DNS Issues']
            Add-ClassificationChart -Sheet $DnsSheet -Data $Sheets['DNS Issues'] -CategoryField 'DnsStatus' -ChartType 'Pie' -ChartTitle 'DNS Issues by Type' -GroupSmallSlices $true
        }
        if ($IncluirDnsRemediation) {
            $RemSheet      = $Workbook.Worksheets.Add([System.Reflection.Missing]::Value, $Workbook.Worksheets.Item($Workbook.Worksheets.Count))
            $RemSheet.Name = 'DNS Remediation'
            Write-DataSheet -Sheet $RemSheet -Data $Sheets['DNS Remediation'] -TabColor $script:TabColorMap['DNS Remediation'] -SummarizationTime $SummarizationTime -GeneratedAt $SheetTimes['DNS Remediation']
        }
        if ($IncluirSummary) {
            $OvSheet           = $Workbook.Worksheets.Add([System.Reflection.Missing]::Value, $Workbook.Worksheets.Item($Workbook.Worksheets.Count))
            $OvSheet.Name      = 'Report Summary'
            $OvSheet.Tab.Color = [int](0xFF + 0xFF * 256 + 0xFF * 65536)
            $TitleFull    = "$DeploymentName  |  Report Summary generated at: $GeneratedAt"
            $T            = $OvSheet.Cells.Item(1, 1)
            $T.Value2     = $TitleFull
            $T.Font.Bold  = $true
            $T.Font.Size  = 12
            $T.Font.Color = $script:CLR_BLACK
            $OvSheet.Range($OvSheet.Cells.Item(1, 1), $OvSheet.Cells.Item(1, 20)).Merge() | Out-Null
            if ($SummarizationTime) {
                $S           = $OvSheet.Cells.Item(2, 1)
                $Label       = 'Last Summarization: '
                $S.Value2    = "$Label$SummarizationTime"
                $S.Font.Size = 11
                $S.Characters(1, $Label.Length).Font.Color                              = $script:CLR_SUMM_LABEL
                $S.Characters(1, $Label.Length).Font.Bold                               = $true
                $S.Characters($Label.Length + 1, $SummarizationTime.Length).Font.Color  = $script:CLR_SUMM_VALUE
                $OvSheet.Range($OvSheet.Cells.Item(2, 1), $OvSheet.Cells.Item(2, 20)).Merge() | Out-Null
            }
            $DataStartRow = 4
            $OvSheet.Cells.Item($DataStartRow,     1).Value2 = 'Status'
            $OvSheet.Cells.Item($DataStartRow,     2).Value2 = 'Total'
            $OvSheet.Cells.Item($DataStartRow + 1, 1).Value2 = 'Compliant'
            $OvSheet.Cells.Item($DataStartRow + 1, 2).Value2 = [double]$Sheets['Compliant'].Count
            $OvSheet.Cells.Item($DataStartRow + 2, 1).Value2 = 'In Progress'
            $OvSheet.Cells.Item($DataStartRow + 2, 2).Value2 = [double]$Sheets['In Progress'].Count
            $OvSheet.Cells.Item($DataStartRow + 3, 1).Value2 = 'Error'
            $OvSheet.Cells.Item($DataStartRow + 3, 2).Value2 = [double]$Sheets['Error'].Count
            $OvSheet.Cells.Item($DataStartRow + 4, 1).Value2 = 'Unknown'
            $OvSheet.Cells.Item($DataStartRow + 4, 2).Value2 = [double]$Sheets['Unknown'].Count
            $SumStatus   = $Sheets['Compliant'].Count + $Sheets['In Progress'].Count + $Sheets['Error'].Count + $Sheets['Unknown'].Count
            $OrphanCount = $TotalCollection - $SumStatus
            if ($OrphanCount -lt 0) { $OrphanCount = 0 }
            $OvSheet.Cells.Item($DataStartRow + 5, 1).Value2 = 'Orphan Records'
            $OvSheet.Cells.Item($DataStartRow + 5, 2).Value2 = [double]$OrphanCount
            $OvSheet.Cells.Item($DataStartRow + 5, 1).Font.Italic = $true
            $OvSheet.Cells.Item($DataStartRow + 5, 2).Font.Italic = $true
            $OvSheet.Cells.Item($DataStartRow + 5, 1).Font.Color  = $script:CLR_GENERATED
            $OvSheet.Cells.Item($DataStartRow + 5, 2).Font.Color  = $script:CLR_GENERATED
            $OvSheet.Cells.Item($DataStartRow + 6, 1).Value2 = 'Total Devices (Collection)'
            $OvSheet.Cells.Item($DataStartRow + 6, 2).Value2 = [double]$TotalCollection
            $OvSheet.Cells.Item($DataStartRow + 6, 1).Font.Bold = $true
            $OvSheet.Cells.Item($DataStartRow + 6, 2).Font.Bold = $true
            $OvSheet.Cells.Item($DataStartRow, 1).Font.Bold      = $true
            $OvSheet.Cells.Item($DataStartRow, 2).Font.Bold      = $true
            $OvSheet.Cells.Item($DataStartRow, 1).Interior.Color = $script:CLR_HEADER_BG
            $OvSheet.Cells.Item($DataStartRow, 2).Interior.Color = $script:CLR_HEADER_BG
            $OvSheet.Cells.Item($DataStartRow, 1).Font.Color     = $script:CLR_HEADER_FG
            $OvSheet.Cells.Item($DataStartRow, 2).Font.Color     = $script:CLR_HEADER_FG
            for ($row = $DataStartRow + 1; $row -le $DataStartRow + 6; $row++) {
                $OvSheet.Cells.Item($row, 1).Font.Size = 11
                $OvSheet.Cells.Item($row, 2).Font.Size = 11
            }
            $OvSheet.Columns('A:B').AutoFit() | Out-Null
            $DataRange = $OvSheet.Range(
                $OvSheet.Cells.Item($DataStartRow + 1, 1),
                $OvSheet.Cells.Item($DataStartRow + 4, 2)
            )
            $ChartObj        = $OvSheet.ChartObjects().Add(220, 30, 460, 360)
            $Chart           = $ChartObj.Chart
            $Chart.ChartType = 5
            $Chart.SetSourceData($DataRange)
            $Chart.HasTitle              = $true
            $Chart.ChartTitle.Text       = 'Deployment Status'
            $Chart.ChartTitle.Font.Size  = 21
            $Chart.ChartTitle.Font.Bold  = $true
            $Chart.ChartTitle.Font.Color = $script:CLR_BLACK
            $PieColors = @($script:PIE_COMPLIANT, $script:PIE_INPROGRESS, $script:PIE_ERROR, $script:PIE_UNKNOWN)
            for ($i = 1; $i -le 4; $i++) {
                $Chart.SeriesCollection(1).Points($i).Format.Fill.ForeColor.RGB = $PieColors[$i - 1]
            }
            $Chart.SeriesCollection(1).Points(1).Explosion = 8
            $Chart.SeriesCollection(1).HasDataLabels = $true
            $DL                  = $Chart.SeriesCollection(1).DataLabels()
            $DL.ShowPercentage   = $true
            $DL.ShowValue        = $true
            $DL.ShowCategoryName = $true
            $DL.Separator        = "\`n"
            $DL.Font.Size        = 8
            $DL.Position         = 2
            try { $DL.ShowLeaderLines = $true } catch { }
            $Chart.HasLegend        = $true
            $Chart.Legend.Position  = -4107
            $Chart.Legend.Font.Size = 14
            $OvSheet.Activate()
        } else {
            $Workbook.Worksheets.Item(1).Activate()
        }
        [void]$Workbook.SaveAs($Path, 51)
        $Workbook.Close($false)
        $Excel.Quit()
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel) | Out-Null
        [System.GC]::Collect()
    }
    function Add-CollectionColumn {
        param ($Data, [string]$CollectionName)
        $Result = New-Object System.Collections.Generic.List[Object]
        if (-not $Data) { return $Result }
        foreach ($Item in $Data) {
            $New = [ordered]@{}
            $Inserted = $false
            foreach ($Prop in $Item.PSObject.Properties) {
                $New[$Prop.Name] = $Prop.Value
                if (-not $Inserted -and $Prop.Name -eq 'DeviceName') {
                    $New['Collection'] = $CollectionName
                    $Inserted = $true
                }
            }
            if (-not $Inserted) {
                $Wrapper = [ordered]@{ Collection = $CollectionName }
                foreach ($Prop in $Item.PSObject.Properties) {
                    $Wrapper[$Prop.Name] = $Prop.Value
                }
                $New = $Wrapper
            }
            $Result.Add([PSCustomObject]$New) | Out-Null
        }
        return $Result
    }
    # === CORPO PRINCIPAL DO SCRIPT ===
    [System.Data.SqlClient.SqlConnection]::ClearAllPools()
    $ConnectionString = "Server=$Server;Database=$Database;Integrated Security=True;TrustServerCertificate=True"
    $CollClauses = @()
    foreach ($cf in $CollectionFilter) {
        $cfEsc = ([string]$cf) -replace "'", "''"
        $CollClauses += "ds.CollectionName LIKE '$cfEsc'"
    }
    $CollFilterClause = '(' + ($CollClauses -join ' OR ') + ')'
    $QueryMenu = @"
    SELECT
        al.Title             AS SoftwareUpdateGroupName,
        ds.AssignmentID      AS AssignmentID,
        ds.CollectionName    AS CollectionName,
        ds.DeploymentTime    AS DeploymentTime,
        ds.SummarizationTime AS SummarizationTime,
        ISNULL(STUFF((
            SELECT DISTINCT '; KB' + ui.ArticleID
            FROM v_CIRelation cr
            JOIN v_UpdateInfo ui ON cr.ToCIID = ui.CI_ID
            WHERE cr.FromCIID = al.CI_ID
              AND cr.RelationType = 1
              AND ui.ArticleID IS NOT NULL
              AND ui.ArticleID <> ''
            FOR XML PATH('')
        ), 1, 2, ''), '')    AS KBList
    FROM v_AuthListInfo al
    JOIN v_DeploymentSummary ds ON al.ModelID = ds.ModelID
    WHERE al.Title LIKE '$DeploymentFilter'
      AND $CollFilterClause
    ORDER BY ds.DeploymentTime DESC
    "@
    $Connection      = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
    $CommandMenu     = New-Object System.Data.SqlClient.SqlCommand($QueryMenu, $Connection)
    $DataAdapterMenu = New-Object System.Data.SqlClient.SqlDataAdapter($CommandMenu)
    $DataTableMenu   = New-Object System.Data.DataTable
    try {
        $Connection.Open()
        $DataAdapterMenu.Fill($DataTableMenu) | Out-Null
        $Connection.Close()
    } catch {
        Write-Error "Falha ao conectar no banco SQL. Erro: $_"
        if ($Connection.State -eq 'Open') { $Connection.Close() }
        return
    }
    if ($DataTableMenu.Rows.Count -eq 0) {
        Write-Host 'Nenhum deployment correspondente localizado.' -ForegroundColor Yellow
        return
    }
    $MenuData = $DataTableMenu |
        Select-Object SoftwareUpdateGroupName, CollectionName, KBList, DeploymentTime, SummarizationTime, AssignmentID
    # === ETAPA 1: SELECAO DO DEPLOYMENT ===
    if ($Auto) {
        # Suporte a multi-collections em modo automático se -AllCollections estiver ativo
        if (-not $AllCollections -and $DataTableMenu.Rows.Count -gt 2) {
            Write-Host "Modo -Auto: $($DataTableMenu.Rows.Count) combinacoes deployment+collection encontradas (max 2)." -ForegroundColor Yellow
            Write-Host "Use o parametro -AllCollections para processar todas ou refine -DeploymentFilter / -CollectionFilter:" -ForegroundColor Yellow
            $MenuData | Format-Table -AutoSize | Out-String | Write-Host
            return
        }
        $NomesDistintos = @($MenuData | Select-Object -ExpandProperty SoftwareUpdateGroupName -Unique)
        if ($NomesDistintos.Count -gt 1) {
            Write-Host "Modo -Auto: collections de deployments diferentes nao podem ser combinadas." -ForegroundColor Yellow
            Write-Host "Deployments encontrados: $($NomesDistintos -join '; ')" -ForegroundColor Yellow
            return
        }
        $ParesSelecionados = @($MenuData)
        $DeploymentName   = $ParesSelecionados[0].SoftwareUpdateGroupName
        Write-Host "Modo -Auto: $($ParesSelecionados.Count) collection(s) selecionada(s) automaticamente." -ForegroundColor DarkCyan
    } else {
        $DeploymentsMenu = $MenuData |
            Group-Object SoftwareUpdateGroupName |
            ForEach-Object {
                $FirstRow = $_.Group | Select-Object -First 1
                $MaxDeploy = ($_.Group | ForEach-Object { $_.DeploymentTime } | Sort-Object -Descending | Select-Object -First 1)
                [PSCustomObject]@{
                    SoftwareUpdateGroupName = $_.Name
                    Collections             = $_.Count
                    KBList                  = $FirstRow.KBList
                    LastDeploymentTime      = $MaxDeploy
                }
            } |
            Sort-Object LastDeploymentTime -Descending
        $DeploymentEscolhido = Show-GridViewWide -InputData $DeploymentsMenu -Title 'Etapa 1/2 - Selecione o Deployment' -OutputMode 'Single'
        if (-not $DeploymentEscolhido) {
            Write-Host 'Execucao cancelada pelo usuario.' -ForegroundColor Yellow
            return
        }
        $DeploymentName = $DeploymentEscolhido.SoftwareUpdateGroupName
        $CollectionsDoDeployment = @($MenuData | Where-Object { $_.SoftwareUpdateGroupName -eq $DeploymentName } | Select-Object CollectionName, KBList, DeploymentTime, SummarizationTime, AssignmentID)
        if ($CollectionsDoDeployment.Count -eq 1) {
            $ParesSelecionados = @($CollectionsDoDeployment)
            Write-Host "Deployment tem apenas 1 collection: selecionada automaticamente ($($CollectionsDoDeployment[0].CollectionName))." -ForegroundColor DarkCyan
        } elseif ($AllCollections) {
            # Se -AllCollections estiver ativo no modo interativo, pula a seleção manual e puxa tudo automaticamente
            $ParesSelecionados = $CollectionsDoDeployment
            Write-Host "Parametro -AllCollections ativo: Selecionadas automaticamente todas as $($CollectionsDoDeployment.Count) collections." -ForegroundColor DarkCyan
        } else {
            while ($true) {
                $Selecionadas = Show-GridViewWide -InputData $CollectionsDoDeployment -Title 'Etapa 2/2 - Selecione as collections (Ctrl/Shift para multiplas)' -OutputMode 'Multiple'
                if (-not $Selecionadas) {
                    Write-Host 'Execucao cancelada pelo usuario.' -ForegroundColor Yellow
                    return
                }
                $Selecionadas = @($Selecionadas)
                if ($Selecionadas.Count -gt 2) {
                    Write-Host "Aviso: Voce selecionou $($Selecionadas.Count) collections sem o parametro -AllCollections ativo." -ForegroundColor Custom
                }
                $ParesSelecionados = $Selecionadas
                break
            }
        }
    }
    # === ETAPA 3: SELECAO DO TIPO DE REPORT ===
    $MenuTipos = @(
        [PSCustomObject]@{ Tipo = 'Completo';    Descricao = 'Todas as abas + Report Summary com grafico' }
        [PSCustomObject]@{ Tipo = 'Error';       Descricao = 'Dispositivos com erro de instalacao'        }
        [PSCustomObject]@{ Tipo = 'In Progress'; Descricao = 'Dispositivos com instalacao em andamento'   }
        [PSCustomObject]@{ Tipo = 'Unknown';     Descricao = 'Dispositivos com status desconhecido'       }
        [PSCustomObject]@{ Tipo = 'Compliant';   Descricao = 'Dispositivos com instalacao concluida'      }
    )
    if ($Auto) {
        $TiposEscolhidos = @($MenuTipos | Where-Object { $_.Tipo -eq 'Completo' })
        Write-Host "Modo -Auto: report Completo selecionado automaticamente." -ForegroundColor DarkCyan
    } else {
        $TiposEscolhidos = Show-GridViewWide -InputData $MenuTipos -Title 'Selecione os reports desejados (Ctrl/Shift para multiplas)' -OutputMode 'Multiple'
        if (-not $TiposEscolhidos) {
            Write-Host 'Execucao cancelada pelo usuario.' -ForegroundColor Yellow
            return
        }
    }
    $IsCompleto = $TiposEscolhidos | Where-Object { $_.Tipo -eq 'Completo' }
    if ($IsCompleto) {
        $TiposParaGerar = @('Error', 'In Progress', 'Unknown', 'Compliant')
        $IncluirSummary = $true
    } else {
        $OrdemPadrao    = @('Error', 'In Progress', 'Unknown', 'Compliant')
        $TiposSel       = @($TiposEscolhidos | ForEach-Object { $_.Tipo })
        $TiposParaGerar = $OrdemPadrao | Where-Object { $TiposSel -contains $_ }
        $IncluirSummary = $false
    }
    $TiposNaoCompliant     = @('Error', 'In Progress', 'Unknown')
    $IncluirDns            = ($TiposParaGerar | Where-Object { $TiposNaoCompliant -contains $_ }).Count -gt 0
    # === NOMES E HEADER (ESTRATEGIA DE ENCURTAMENTO INTELIGENTE) ===
    $CollectionNamesArr = @($ParesSelecionados | ForEach-Object { [string]$_.CollectionName })
    # Pega o formato solicitado com o contador do resto
    if ($CollectionNamesArr.Count -gt 2) {
        $FirstColl  = $CollectionNamesArr[0]
        $SecondColl = $CollectionNamesArr[1]
        $RestCount  = $CollectionNamesArr.Count - 2
        $CollectionConcat = "$FirstColl + $SecondColl + e mais $($RestCount)_cols"
    } else {
        $CollectionConcat = $CollectionNamesArr -join ' + '
    }
    # Remove KBs duplicadas para a string base
    $RawKbs = if ($ParesSelecionados.KBList -is [System.DBNull] -or [string]::IsNullOrWhiteSpace([string]$ParesSelecionados.KBList)) { '' } else { [string]$ParesSelecionados.KBList }
    $KBList = if ($RawKbs) {
        @($RawKbs -split '; ' | ForEach-Object { $_.Trim() } | Select-Object -Unique) -join '; '
    } else { '' }
    # SummarizationTime mais recente entre os pares (UTC -> local)
    $SumTimesValidas = @()
    foreach ($Par in $ParesSelecionados) {
        if ($Par.SummarizationTime -is [System.DBNull]) { continue }
        $SumTimesValidas += [datetime]$Par.SummarizationTime
    }
    $SummarizationTime = if ($SumTimesValidas.Count -eq 0) { '' } else {
        $MaxUtc   = ($SumTimesValidas | Sort-Object -Descending | Select-Object -First 1)
        $MaxLocal = [System.TimeZoneInfo]::ConvertTimeFromUtc($MaxUtc, [System.TimeZoneInfo]::Local)
        $MaxLocal.ToString('M/d/yyyy h:mm:ss tt')
    }
    $DateStamp      = Get-DateStamp
    $SafeName       = $DeploymentName  -replace '[\\\\/:*?"<>|]', '_'
    $SafeCollection = $CollectionConcat -replace '[\\\\/:*?"<>|]', '_'
    $TipoSufixo     = if ($IsCompleto) { 'Completo' } else { ($TiposParaGerar -join '_') }
    $KBSuffix       = if ($KBList) { ' - ' + ($KBList -replace '; ', '_' -replace '[\\\\/:*?"<>|]', '_') } else { '' }
    $ScriptDir      = $OutputDirectory
    # Tentativa 1: Nome Ideal Completo
    $XlsxPath = Join-Path $ScriptDir "$SafeName - $SafeCollection - $TipoSufixo - $DateStamp$KBSuffix.xlsx"
    # Se estourar 215 caracteres (limite seguro para caminhos UNC no Excel COM), aplicamos a redução inteligente
    # Se estourar 215 caracteres, encurta agressivamente o Deployment e mantém os KBs
    if ($XlsxPath.Length -gt 215) {
        # Reduz o nome do Deployment para apenas 15 caracteres para dar espaço para as KBs
        $ShortDeployment = if ($SafeName.Length -gt 15) { $SafeName.Substring(0, 15) + '...' } else { $SafeName }
        # Mantém o KBSuffix no nome do arquivo
        $XlsxPath = Join-Path $ScriptDir "$ShortDeployment - $SafeCollection - $TipoSufixo - $DateStamp$KBSuffix.xlsx"
    }
    # Fallback Extremo de Segurança (Apenas se o caminho da pasta de rede for absurdamente gigante)
    if ($XlsxPath.Length -gt 240) {
        $ShortCollection = "$($CollectionNamesArr[0])_MultiColl" -replace '[\\\\/:*?"<>|]', '_'
        $XlsxPath = Join-Path $ScriptDir "$SafeName - $ShortCollection - $DateStamp.xlsx"
    }
    $CollLabel = if ($ParesSelecionados.Count -gt 1) { 'Collections' } else { 'Collection' }
    Write-Host "Deployment: $DeploymentName" -ForegroundColor Green
    Write-Host ("{0}: {1}" -f $CollLabel, ($CollectionNamesArr -join '; ')) -ForegroundColor Green
    Write-Host "KBs: $(if ($KBList) { $KBList } else { 'N/A' })" -ForegroundColor Green
    Write-Host "Reports: $($TiposParaGerar -join ', ')$(if ($IncluirSummary) { ' + Report Summary' })$(if ($IncluirDns) { ' + DNS Issues' })" -ForegroundColor Cyan
    Write-Host "Arquivo: $XlsxPath" -ForegroundColor DarkGray
    Write-Host "Coletando dados..." -ForegroundColor Cyan
    $AllSheets  = @{}
    $SheetTimes = @{}
    foreach ($T in @('Error', 'In Progress', 'Unknown', 'Compliant', 'DNS Issues', 'DNS Remediation')) {
        $AllSheets[$T]  = New-Object System.Collections.Generic.List[Object]
        $SheetTimes[$T] = (Get-Date).ToString('M/d/yyyy h:mm:ss tt')
    }
    $TotalCollection      = 0
    $TodosIssueTargets    = New-Object System.Collections.Generic.List[Object]
    $TotalDnsChecked      = 0
    $TotalDnsOk           = 0
    $TotalDnsOffline      = 0
    $DnsCheckAlgumExecutou = $false
    $TiposParaBuscar = if ($IncluirSummary) { @('Error', 'In Progress', 'Unknown', 'Compliant') } else { $TiposParaGerar }
    for ($IdxPar = 0; $IdxPar -lt $ParesSelecionados.Count; $IdxPar++) {
        $Par           = $ParesSelecionados[$IdxPar]
        $AssignmentID  = [int]$Par.AssignmentID
        $CollNameAtual = [string]$Par.CollectionName
        Write-Host ""
        Write-Host (">> Processando collection {0}/{1}: {2} (AssignmentID {3})" -f ($IdxPar + 1), $ParesSelecionados.Count, $CollNameAtual, $AssignmentID) -ForegroundColor Yellow
        if ($IncluirSummary) {
            $TotPar = Get-CollectionTotal -AssignmentID $AssignmentID -ConnectionString $ConnectionString
            Write-Host "  >> Total de dispositivos na collection: $TotPar" -ForegroundColor DarkCyan
            $TotalCollection += $TotPar
        }
        foreach ($Tipo in @('Error', 'In Progress', 'Unknown', 'Compliant')) {
            if ($TiposParaBuscar -contains $Tipo) {
                Write-Host "  >> $Tipo..." -ForegroundColor DarkCyan
                try {
                    $Resultado = Get-ReportData -Tipo $Tipo -AssignmentID $AssignmentID -ConnectionString $ConnectionString -ErrorTable $ErrorTable -DomainSuffix $DomainSuffix
                    if ($ParesSelecionados.Count -gt 1) {
                        $Resultado = Add-CollectionColumn -Data $Resultado -CollectionName $CollNameAtual
                    }
                    foreach ($Item in $Resultado) { $AllSheets[$Tipo].Add($Item) | Out-Null }
                    $SheetTimes[$Tipo] = (Get-Date).ToString('M/d/yyyy h:mm:ss tt')
                    Write-Host "    $($Resultado.Count) dispositivo(s)" -ForegroundColor DarkGray
                } catch {
                    Write-Host "    Erro ao buscar $Tipo : $_" -ForegroundColor Yellow
                }
            }
        }
        if ($IncluirDns) {
            Write-Host "  >> DNS Check (forward + reverse + ping validation)..." -ForegroundColor DarkCyan
            try {
                $DnsCheck = Get-DnsCheckData -AssignmentID $AssignmentID -ConnectionString $ConnectionString -TiposSelecionados $TiposParaGerar -DomainSuffix $DomainSuffix
                if ($ParesSelecionados.Count -gt 1) {
                    $DnsCheck.Issues = Add-CollectionColumn -Data $DnsCheck.Issues -CollectionName $CollNameAtual
                }
                foreach ($Item in $DnsCheck.Issues) { $AllSheets['DNS Issues'].Add($Item) | Out-Null }
                foreach ($Item in $DnsCheck.IssueTargets)   { $TodosIssueTargets.Add($Item) | Out-Null }
                $TotalDnsChecked += $DnsCheck.TotalChecked
                $TotalDnsOk      += $DnsCheck.TotalOk
                $TotalDnsOffline += $DnsCheck.TotalOffline
                $SheetTimes['DNS Issues'] = (Get-Date).ToString('M/d/yyyy h:mm:ss tt')
                $DnsCheckAlgumExecutou    = $true
                Write-Host "    $($DnsCheck.TotalChecked) verificado(s) | $($DnsCheck.TotalOk) DNS OK | $($DnsCheck.TotalOffline) Offline (Ignorados) | $($DnsCheck.Issues.Count) com problema real de DNS" -ForegroundColor DarkGray
            } catch {
                Write-Host "    Erro ao executar DNS Check: $_" -ForegroundColor Yellow
            }
        }
    }
    $IncluirDnsRemediation = $false
    if ($IncluirDns -and $TodosIssueTargets.Count -gt 0 -and -not $Auto) {
        Write-Host ""
        $Resp = Read-Host "Executar remediacao DNS (flushdns + registerdns via WinRM) nas $($TodosIssueTargets.Count) maquina(s) com problema? (S/N)"
        if ($Resp -match '^[SsYy]') {
            $IncluirDnsRemediation = $true
            try {
                $Remediadas = Invoke-DnsRemediation -IssueTargets $TodosIssueTargets
                if ($ParesSelecionados.Count -gt 1) {
                    $Remediadas = Add-CollectionColumn -Data $Remediadas -CollectionName "Consolidated"
                }
                foreach ($Item in $Remediadas) { $AllSheets['DNS Remediation'].Add($Item) | Out-Null }
                $SheetTimes['DNS Remediation'] = (Get-Date).ToString('M/d/yyyy h:mm:ss tt')
            } catch {
                Write-Host "    Erro na remediacao DNS: $_" -ForegroundColor Yellow
            }
        } else {
            Write-Host "Remediacao DNS ignorada." -ForegroundColor DarkGray
        }
    } elseif ($Auto -and $IncluirDns -and $TodosIssueTargets.Count -gt 0) {
        Write-Host "Modo -Auto: remediacao DNS ignorada." -ForegroundColor DarkGray
    }
    $GeneratedAt = (Get-Date).ToString('M/d/yyyy h:mm:ss tt')
    Write-Host "\`n=== RESUMO ===" -ForegroundColor Yellow
    foreach ($Tipo in $TiposParaGerar) {
        Write-Host ('{0,-20} {1,5} dispositivo(s)' -f $Tipo, $AllSheets[$Tipo].Count) -ForegroundColor White
    }
    if ($IncluirDns) {
        Write-Host ('{0,-20} {1,5} dispositivo(s)' -f 'DNS Issues', $AllSheets['DNS Issues'].Count) -ForegroundColor Magenta
    }
    if ($IncluirDnsRemediation) {
        $FixedTotal = ($AllSheets['DNS Remediation'] | Where-Object { $_.Fixed -eq 'Yes' }).Count
        Write-Host ('{0,-20} {1,5} corrigida(s) de {2}' -f 'DNS Remediation', $FixedTotal, $AllSheets['DNS Remediation'].Count) -ForegroundColor Magenta
    }
    if ($IncluirSummary) {
        $SumStatusConsole   = $AllSheets['Compliant'].Count + $AllSheets['In Progress'].Count + $AllSheets['Error'].Count + $AllSheets['Unknown'].Count
        $OrphanCountConsole = $TotalCollection - $SumStatusConsole
        if ($OrphanCountConsole -lt 0) { $OrphanCountConsole = 0 }
        Write-Host ('{0,-20} {1,5} registro(s)' -f 'Orphan Records', $OrphanCountConsole) -ForegroundColor DarkGray
        Write-Host ('{0,-20} {1,5} dispositivo(s)' -f 'Total (Collection)', $TotalCollection) -ForegroundColor Cyan
    }
    if ($AllSheets['Error'].Count -gt 0 -and $TiposParaGerar -contains 'Error') {
        Write-Host "\`n=== ERROS ===" -ForegroundColor Yellow
        $AllSheets['Error'] |
            Group-Object ErrorCodeHex |
            Sort-Object Count -Descending |
            ForEach-Object {
                $Desc = ($_.Group | Select-Object -First 1).TraducaoNativaDoSO
                Write-Host ('{0,-15} {1,4} dispositivo(s) >> {2}' -f $_.Name, $_.Count, $Desc) -ForegroundColor White
            }
    }
    if ($AllSheets['In Progress'].Count -gt 0 -and $TiposParaGerar -contains 'In Progress') {
        Write-Host "\`n=== IN PROGRESS ===" -ForegroundColor Yellow
        $AllSheets['In Progress'] |
            Group-Object Status |
            Sort-Object Count -Descending |
            ForEach-Object {
                Write-Host ('{0,-40} {1,4} dispositivo(s)' -f $_.Name, $_.Count) -ForegroundColor White
            }
    }
    if ($IncluirDns -and $AllSheets['DNS Issues'].Count -gt 0) {
        Write-Host "\`n=== DNS ISSUES ===" -ForegroundColor Yellow
        $AllSheets['DNS Issues'] |
            Group-Object DnsStatus |
            Sort-Object Count -Descending |
            ForEach-Object {
                Write-Host ('{0,-35} {1,4} dispositivo(s)' -f $_.Name, $_.Count) -ForegroundColor White
            }
    }
    Write-Host "\`nExportando planilha..." -ForegroundColor Cyan
    try {
        Export-XlsxMultiSheet \`
            -Sheets $AllSheets \`
            -SheetTimes $SheetTimes \`
            -TiposSelecionados $TiposParaGerar \`
            -IncluirSummary $IncluirSummary \`
            -IncluirDns $IncluirDns \`
            -IncluirDnsRemediation $IncluirDnsRemediation \`
            -TotalCollection $TotalCollection \`
            -Path $XlsxPath \`
            -SummarizationTime $SummarizationTime \`
            -DeploymentName $DeploymentName \`
            -GeneratedAt $GeneratedAt
        Write-Host "Planilha exportada com sucesso para: $XlsxPath" -ForegroundColor Green
    } catch {
        Write-Host "Erro ao exportar XLSX:" -ForegroundColor Red
        Write-Host "  Mensagem : $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  Tipo     : $($_.Exception.GetType().FullName)" -ForegroundColor Red
        Write-Host "  Script   : $($_.InvocationInfo.ScriptName)" -ForegroundColor Red
        Write-Host "  Linha    : $($_.InvocationInfo.ScriptLineNumber)" -ForegroundColor Red
        Write-Host "  Comando  : $($_.InvocationInfo.Line.Trim())" -ForegroundColor Red
        throw
    }
    # === MENU DE ACOES POS-EXPORTACAO ===
    if (-not $Auto) {
        $AbasMeta = @(
            [PSCustomObject]@{ Aba = 'Error';       Campo = 'ErrorCodeHex' }
            [PSCustomObject]@{ Aba = 'In Progress'; Campo = 'Status'       }
            [PSCustomObject]@{ Aba = 'Unknown';     Campo = 'Category'     }
            [PSCustomObject]@{ Aba = 'DNS Issues';  Campo = 'DnsStatus'    }
        )
        while ($true) {
            $MenuAcoes = @(
                [PSCustomObject]@{ Opcao = 'Email reboot - maquinas Online com Pending system restart'; Codigo = 'PendingRestart' }
                [PSCustomObject]@{ Opcao = 'Email reboot - filtrar por aba + valor da classificacao';   Codigo = 'AbaValor'       }
                [PSCustomObject]@{ Opcao = 'Sair';                                                       Codigo = 'Sair'           }
            )
            $Escolha = Show-GridViewWide -InputData $MenuAcoes -Title 'Acoes pos-exportacao' -OutputMode 'Single'
            if (-not $Escolha -or $Escolha.Codigo -eq 'Sair') { break }
            switch ($Escolha.Codigo) {
                'PendingRestart' {
                    if (-not ($TiposParaGerar -contains 'In Progress') -or $AllSheets['In Progress'].Count -eq 0) {
                        Write-Host "Aba 'In Progress' nao gerada ou vazia." -ForegroundColor Yellow
                        continue
                    }
                    $PendingRestartOnline = @($AllSheets['In Progress'] | Where-Object {
                        $_.Status -eq 'Pending system restart' -and $_.StatusDoPing -eq 'Online'
                    })
                    if ($PendingRestartOnline.Count -eq 0) {
                        Write-Host "Nenhuma maquina Online com Pending system restart." -ForegroundColor Yellow
                        continue
                    }
                    Write-Host ""
                    $Resp = Read-Host "Enviar email de reboot para $($PendingRestartOnline.Count) maquina(s) online com Pending system restart? (S/N)"
                    if ($Resp -match '^[SsYy]') {
                        Send-PendingRestartReminders -Devices $PendingRestartOnline -ConnectionString $ConnectionString
                    } else {
                        Write-Host "Envio de emails ignorado." -ForegroundColor DarkGray
                    }
                }
                'AbaValor' {
                    $AbasDisponiveis = @($AbasMeta | Where-Object {
                        $AllSheets[$_.Aba] -and $AllSheets[$_.Aba].Count -gt 0
                    } | ForEach-Object {
                        [PSCustomObject]@{
                            Aba                = $_.Aba
                            CampoClassificacao = $_.Campo
                            Total              = $AllSheets[$_.Aba].Count
                        }
                    })
                    if ($AbasDisponiveis.Count -eq 0) {
                        Write-Host "Nenhuma aba elegivel com dados (Error, In Progress, Unknown, DNS Issues)." -ForegroundColor Yellow
                        continue
                    }
                    $AbaEscolhida = Show-GridViewWide -InputData $AbasDisponiveis -Title 'Selecione a aba' -OutputMode 'Single'
                    if (-not $AbaEscolhida) { continue }
                    $NomeAba = [string]$AbaEscolhida.Aba
                    $Campo   = [string]$AbaEscolhida.CampoClassificacao
                    $ValoresMenu = @($AllSheets[$NomeAba] |
                        Group-Object -Property $Campo |
                        Sort-Object Count -Descending |
                        ForEach-Object {
                            $obj = [ordered]@{}
                            $obj[$Campo]   = $_.Name
                            $obj.Quantidade = $_.Count
                            [PSCustomObject]$obj
                        })
                    $ValorEscolhido = Show-GridViewWide -InputData $ValoresMenu -Title "Selecione o valor de $Campo na aba $NomeAba" -OutputMode 'Single'
                    if (-not $ValorEscolhido) { continue }
                    $ValorFiltro = [string]$ValorEscolhido.$Campo
                    $TemPing = ($AllSheets[$NomeAba].PSObject.Properties.Name -contains 'StatusDoPing')
                    $Filtradas = if ($TemPing) {
                        @($AllSheets[$NomeAba] | Where-Object { $_.$Campo -eq $ValorFiltro -and $_.StatusDoPing -eq 'Online' })
                    } else {
                        @($AllSheets[$NomeAba] | Where-Object { $_.$Campo -eq $ValorFiltro })
                    }
                    if ($Filtradas.Count -eq 0) {
                        $Suffix = if ($TemPing) { ' Online' } else { '' }
                        Write-Host "Nenhuma maquina$Suffix com $Campo = '$ValorFiltro' na aba '$NomeAba'." -ForegroundColor Yellow
                        continue
                    }
                    Write-Host ""
                    $PingFilterStr = if ($TemPing) { ' (Online)' } else { '' }
                    $Resp = Read-Host "Enviar email de reboot para $($Filtradas.Count) maquina(s)$PingFilterStr da aba '$NomeAba' com $Campo = '$ValorFiltro'? (S/N)"
                    if ($Resp -match '^[SsYy]') {
                        Send-PendingRestartReminders -Devices $Filtradas -ConnectionString $ConnectionString
                    } else {
                        Write-Host "Envio ignorado." -ForegroundColor DarkGray
                    }
                }
            }
        }
    }
    #Get-Process -Name 'EXCEL' | Stop-Process -Force


    if ([string]::IsNullOrWhiteSpace([string]$XlsxPath)) {
        throw 'O Grid terminou sem informar o caminho do arquivo gerado.'
    }
    if (-not (Test-Path -LiteralPath $XlsxPath -PathType Leaf)) {
        throw "O Grid terminou, mas o arquivo não foi localizado: $XlsxPath"
    }
    $GridFile = Get-Item -LiteralPath $XlsxPath -ErrorAction Stop
    if ($GridFile.Length -le 0) {
        throw "O Grid gerou um arquivo vazio: $($GridFile.FullName)"
    }
    [PSCustomObject]@{
        Success        = $true
        ReportPath     = $GridFile.FullName
        DeploymentName = $DeploymentName
        Collections    = @($CollectionNamesArr)
        GeneratedAt    = Get-Date
    }
}

function Invoke-DailyPatchReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })][string]$GridReportPath,
        [Parameter(Mandatory)][string]$SCCMServer,
        [Parameter(Mandatory)][string]$SiteCode,
        [Parameter(Mandatory)][string]$CollectionID,
        [Parameter(Mandatory)][string]$ReportDirectory,
        [Parameter(Mandatory)][string]$LocalWorkingDirectory
    )
    $ErrorActionPreference = 'Stop'
    if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
        throw 'O módulo ImportExcel não está instalado. Use o botão Install ImportExcel na interface.'
    }
    Import-Module ImportExcel -ErrorAction Stop
    if (-not (Test-Path -LiteralPath $ReportDirectory)) { New-Item -ItemType Directory -Path $ReportDirectory -Force | Out-Null }
    if (-not (Test-Path -LiteralPath $LocalWorkingDirectory)) { New-Item -ItemType Directory -Path $LocalWorkingDirectory -Force | Out-Null }
    $CurrentDate    = Get-Date -Format 'dd-MM-yyyy'
    $LocalExcelPath = Join-Path $LocalWorkingDirectory "SCCM_Collection_Members_${CurrentDate}.xlsx"
    $DateToken      = Get-Date -Format 'dd.MM.yy'
    $CurrentMonth   = (Get-Date).ToString('MMMM', [cultureinfo]'en-US')
    $PreviousMonth  = (Get-Date).AddMonths(-1).ToString('MMMM', [cultureinfo]'en-US')
    $ComparisonName = "$CurrentMonth x $PreviousMonth"
    $DailyPatchFile = Join-Path $ReportDirectory "$ComparisonName Workplace Daily Patch Report - ${DateToken}.xlsx"
    $SourceNetworkDir = Split-Path -Parent $GridReportPath
    $SourceFilePattern = Split-Path -Leaf $GridReportPath
    # ==============================================================================
    # --- PART 2: FILE LOCATION, REPLICATION, AND INITIAL WORKBOOK CLEANSING ---
    # ==============================================================================
    $LastFile = Get-ChildItem -Path $ReportDirectory -Filter "*.xlsx" | 
                Sort-Object LastWriteTime | 
                Select-Object -Last 1
     
    if (-not $LastFile) {
        Throw "No Excel files found in the report directory to replicate."
    }
     
    Write-Host "Replicating latest file '${LastFile.Name}' to the new daily instance..." -ForegroundColor Cyan
    Copy-Item -Path $LastFile.FullName -Destination $DailyPatchFile -Force
     
    Write-Host "Opening target workbook stream to clear legacy content..." -ForegroundColor Yellow
    $ExcelPackage = Open-ExcelPackage -Path $DailyPatchFile
     
    # Clean 'status' Worksheet (Preserve row 1 headers, clear everything below row 2)
    $StatusWorksheet = $ExcelPackage.Workbook.Worksheets["status"]
    if ($StatusWorksheet -and $StatusWorksheet.Dimension) {
        $MaxRowsStatus = $StatusWorksheet.Dimension.End.Row
        if ($MaxRowsStatus -ge 2) {
            $StatusWorksheet.DeleteRow(2, ($MaxRowsStatus - 1))
        }
    }
     
    # Completely purge data cells from 'error', 'in progress', and 'unknown' sheets
    $TabsToClear = @("error", "in progress", "unknown")
    foreach ($Tab in $TabsToClear) {
        $Worksheet = $ExcelPackage.Workbook.Worksheets[$Tab]
        if ($Worksheet -and $Worksheet.Dimension) {
            $MaxRows = $Worksheet.Dimension.End.Row
            $Worksheet.DeleteRow(1, $MaxRows)
        }
    }
     
    Close-ExcelPackage -ExcelPackage $ExcelPackage
    Write-Host "Part 2 completed: Daily patch report created and staging areas cleared." -ForegroundColor Green
    # ==============================================================================
    # --- PART 3: REMOTE INVOCATION AND SCCM COLLECTION DATA GATHERING ---
    # ==============================================================================
    Write-Host "Connecting to server $SCCMServer to fetch live inventory dataset..." -ForegroundColor Cyan
     
    $RemoteData = Invoke-Command -ComputerName $SCCMServer -ScriptBlock {
        param($SiteCode, $CollectionID)
        
        $global:CMPSSuppressFastNotUsedCheck = $true
        $WarningPreference = "SilentlyContinue"
        
        $ModuleCandidates = @(
            (Join-Path ([Environment]::GetEnvironmentVariable('SMS_ADMIN_UI_PATH')) '..\ConfigurationManager.psd1'),
            'C:\Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin\ConfigurationManager.psd1',
            'C:\Program Files\Microsoft Configuration Manager\AdminConsole\bin\ConfigurationManager.psd1',
            'D:\Program Files\Microsoft Configuration Manager\AdminConsole\bin\ConfigurationManager.psd1'
        ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
        $ModulePath = $ModuleCandidates | Select-Object -First 1
        if (-not $ModulePath) { throw 'ConfigurationManager.psd1 was not found on the SMS Provider.' }
        Import-Module $ModulePath -ErrorAction Stop
        Set-Location "${SiteCode}:"
        
        $Devices = Get-CMDevice -CollectionId $CollectionID -Fast
        
        $Devices | Select-Object \`
            @{Name="Device";                 Expression={$_.Name}},
            @{Name="Client type";            Expression={if($_.ClientType -eq 1){"Computer"}else{"Other"}}},
            @{Name="Client";                 Expression={if($_.IsClient){"Yes"}else{"No"}}},
            @{Name="Current logged on user"; Expression={$_.LastLogonUser}},
            @{Name="Site code";              Expression={$_.SiteCode}},
            @{Name="Client activity";        Expression={if($_.IsActive){"Active"}else{"Inactive"}}},
            @{Name="AD Site";                Expression={$_.ADSiteName}},
            @{Name="Device status";          Expression={if($_.CNIsOnline){"Online"}else{"Offline"}}},
            @{Name="Domain";                 Expression={$_.Domain}},
            @{Name="Last online time";       Expression={if($_.CNLastOnlineTime){[DateTime]$_.CNLastOnlineTime | Get-Date -Format "M/d/yyyy H:mm"}else{""}}},
            @{Name="OS build number";        Expression={$_.ClientVersion}},
            @{Name="Pending restart";        Expression={if($_.IsClientRestartPending){"Yes"}else{"No"}}}
    } -ArgumentList $SiteCode, $CollectionID
     
    Write-Host "Part 3 completed: SCCM remote collection data extraction finished." -ForegroundColor Green
    # ==============================================================================
    # --- PART 4: LOCAL EXTRACTION BACKUP AND STATUS SHEET POPULATION ---
    # ==============================================================================
    if ($RemoteData) {
        Write-Host "Filtering out session wrapper metadata from the remote payload..." -ForegroundColor Cyan
        
        $LocalFolder = Split-Path $LocalExcelPath
        if (-not (Test-Path $LocalFolder)) {
            New-Item -ItemType Directory -Path $LocalFolder -Force | Out-Null
        }
     
        $CleanData = $RemoteData | Select-Object * -ExcludeProperty PS* , RunspaceId
        $CleanData | Export-Excel -Path $LocalExcelPath -WorksheetName "SCCM Collection Members" -AutoSize -AutoFilter -ClearSheet
        Write-Host "Success! Local raw dataset backup written to: $LocalExcelPath" -ForegroundColor Green
        
        Write-Host "Injecting live dataset onto target 'status' worksheet..." -ForegroundColor Cyan
        if (Test-Path $DailyPatchFile) {
            
            $ExcelPackage = Open-ExcelPackage -Path $DailyPatchFile
            $StatusSheet  = $ExcelPackage.Workbook.Worksheets["status"]
            
            if ($StatusSheet -and $StatusSheet.Dimension) {
                $MaxCols = $StatusSheet.Dimension.End.Column
                $Headers = for ($col = 1; $col -le $MaxCols; $col++) { $StatusSheet.Cells[1, $col].Value }
                Close-ExcelPackage -ExcelPackage $ExcelPackage
                
                $AlignedData = $CleanData | Select-Object $Headers
                $AlignedData | Export-Excel -Path $DailyPatchFile -WorksheetName "status" -StartRow 2 -NoHeader
                Write-Host "Part 4 completed: Worksheet 'status' successfully populated." -ForegroundColor Green
            } else {
                Close-ExcelPackage -ExcelPackage $ExcelPackage
                $CleanData | Export-Excel -Path $DailyPatchFile -WorksheetName "status" -StartRow 2 -NoHeader
            }
        } else {
            Write-Warning "Target file reference dead-end: $DailyPatchFile"
        }
    } else {
        Write-Warning "Zero arrays returned from the remote infrastructure endpoint. Aborting data injection."
    }
    # ==============================================================================
    # --- PART 5: NETWORK SCANNING, METADATA STRIPPING, AND DYNAMIC VLOOKUP ---
    # ==============================================================================
    if ($RemoteData) { 
        Write-Host "Validating and refreshing active network share connectivity..." -ForegroundColor Cyan
        
        if (-not (Test-Path -Path $SourceNetworkDir)) {
            Write-Warning "Network node locked or sleeping. Initializing direct pipeline wake-up..."
            cmd.exe /c "dir \`"$SourceNetworkDir\`"" > $null
        }
        Write-Host "Using the exact Grid report generated in stage 1..." -ForegroundColor Cyan
        $ResolvedSourceFile = Get-Item -LiteralPath $GridReportPath -ErrorAction Stop
     
        if ($ResolvedSourceFile) {
            Write-Host "Target matched! Importing arrays from network node: $($ResolvedSourceFile.Name)" -ForegroundColor Green
            
            $TargetSheets = Get-ExcelSheetInfo -Path $DailyPatchFile
            $InProgTargetName = $TargetSheets.Name | Where-Object { $_ -match "^In\s?progress$" } | Select-Object -First 1
            if (-not $InProgTargetName) { $InProgTargetName = "In progress" }
     
            $ErrorData      = Import-Excel -Path $ResolvedSourceFile.FullName -WorksheetName "Error" -StartRow 3 -EndColumn 8
            $InProgressData = Import-Excel -Path $ResolvedSourceFile.FullName -WorksheetName "In progress" -StartRow 3 -EndColumn 7
            $UnknownData    = Import-Excel -Path $ResolvedSourceFile.FullName -WorksheetName "Unknown" -StartRow 3 -EndColumn 7
     
            if ($ErrorData) { $ErrorData | Export-Excel -Path $DailyPatchFile -WorksheetName "Error" -StartRow 1 -ClearSheet -AutoSize }
            if ($InProgressData) { $InProgressData | Export-Excel -Path $DailyPatchFile -WorksheetName $InProgTargetName -StartRow 1 -ClearSheet -AutoSize }
            if ($UnknownData) { $UnknownData | Export-Excel -Path $DailyPatchFile -WorksheetName "Unknown" -StartRow 1 -ClearSheet -AutoSize }
     
            $ExcelPackage = Open-ExcelPackage -Path $DailyPatchFile
     
            $TargetTabs = @("Error", $InProgTargetName, "Unknown")
            foreach ($TabName in $TargetTabs) {
                $SheetObject = $ExcelPackage.Workbook.Worksheets[$TabName]
                if ($SheetObject -and $SheetObject.Dimension) {
                    Write-Host "Stripping duplicated row 1 layout template from: $TabName" -ForegroundColor Magenta
                    $SheetObject.DeleteRow(1)
                }
            }
     
            # --- SAFE VLOOKUP FORMULA INJECTION ENGINE ---
            Write-Host "Deploying real-time VLOOKUP arrays onto the master 'status' tracking layer..." -ForegroundColor Cyan
            $StatusSheet = $ExcelPackage.Workbook.Worksheets["status"]
            
            if ($StatusSheet) {
                $StatusSheet.Cells["M1"].Value = "Error LookUp"
                $StatusSheet.Cells["N1"].Value = "In Progress LookUp"
                $StatusSheet.Cells["O1"].Value = "Unknown LookUp"
     
                $StartRow = 2
                $TotalRows = $CleanData.Count
     
                if ($TotalRows -gt 0) {
                    $EndRow = $StartRow + ($TotalRows - 1)
                    Write-Host "Writing VLOOKUP formulas to active evaluation layer..." -ForegroundColor Magenta
                    
                    # FIX: Utilizing the explicit .Formula property enables Excel engine compilation
                    # Added the dynamic implicit intersection prefix (@) as requested
                    for ($i = $StartRow; $i -le $EndRow; $i++) {
                        $StatusSheet.Cells["M$i"].Formula = "=VLOOKUP(@A:A,Error!A:G,7,0)"
                        $StatusSheet.Cells["N$i"].Formula = "=VLOOKUP(@A:A,'$InProgTargetName'!A:E,5,0)"
                        $StatusSheet.Cells["O$i"].Formula = "=VLOOKUP(@A:A,Unknown!A:E,5,0)"
                    }
                }
            }
     
            Close-ExcelPackage -ExcelPackage $ExcelPackage
            Write-Host "Part 5 completed: Data links attached and formulas bound successfully!" -ForegroundColor Green
            Write-Host "AUTOMATION PROCESS FULLY EXECUTED AND CONCLUDED!" -ForegroundColor Green
        } else {
            throw "CRITICAL: The Grid report was not found: $GridReportPath"
        }
    }
    if (-not (Test-Path -LiteralPath $DailyPatchFile -PathType Leaf)) {
        throw "O Daily Patch terminou sem criar o arquivo final: $DailyPatchFile"
    }
    Get-Item -LiteralPath $DailyPatchFile
}


function Show-AutomationGui {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $auto = Get-AutomaticEnvironment
    $saved=@{}
    if(Test-Path -LiteralPath $ConfigFile){ try { $o=Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json; $o.PSObject.Properties|%{$saved[$_.Name]=$_.Value} } catch{} }
    $defaults=@{}; $auto.PSObject.Properties|%{$defaults[$_.Name]=$_.Value}; foreach($k in $saved.Keys){$defaults[$k]=$saved[$k]}
    $form=New-Object Windows.Forms.Form
    $form.Text='Daily Patch Automation - Grid + MS Daily Patch'; $form.StartPosition='CenterScreen'; $form.Size=New-Object Drawing.Size(980,760); $form.MinimumSize=New-Object Drawing.Size(900,680); $form.MaximizeBox=$true
    $panel=New-Object Windows.Forms.TableLayoutPanel; $panel.Dock='Top'; $panel.Height=470; $panel.ColumnCount=2; $panel.RowCount=12; $panel.Padding=New-Object Windows.Forms.Padding(12); $panel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute,210))); $panel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
    $fields=[ordered]@{SqlServer='SQL Server';Database='Database';SmsProvider='SMS Provider';SiteCode='Site Code';DomainSuffix='Domain suffix';CollectionId='Daily Patch Collection ID';DeploymentFilter='Deployment filter';CollectionFilter='Collection filter';GridOutputDirectory='Grid output share';ReportDirectory='Daily report directory';LocalWorkingDirectory='Local working directory'}
    $boxes=@{}; $r=0
    foreach($key in $fields.Keys){$lab=New-Object Windows.Forms.Label;$lab.Text=$fields[$key];$lab.Dock='Fill';$lab.TextAlign='MiddleLeft';$tb=New-Object Windows.Forms.TextBox;$tb.Dock='Fill';$tb.Text=[string]$defaults[$key];$boxes[$key]=$tb;$panel.Controls.Add($lab,0,$r);$panel.Controls.Add($tb,1,$r);$r++}
    $form.Controls.Add($panel)
    $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Top';$buttons.Height=48;$buttons.Padding=New-Object Windows.Forms.Padding(12,6,0,0)
    $detect=New-Object Windows.Forms.Button;$detect.Text='Detect Environment';$detect.Width=145
    $test=New-Object Windows.Forms.Button;$test.Text='Test Connections';$test.Width=145
    $install=New-Object Windows.Forms.Button;$install.Text='Install ImportExcel';$install.Width=145
    $run=New-Object Windows.Forms.Button;$run.Text='Run Full Process';$run.Width=160
    $buttons.Controls.AddRange(@($detect,$test,$install,$run));$form.Controls.Add($buttons)
    $log=New-Object Windows.Forms.RichTextBox;$log.Dock='Fill';$log.ReadOnly=$true;$log.Font=New-Object Drawing.Font('Consolas',10);$log.BackColor=[Drawing.Color]::FromArgb(25,25,25);$log.ForeColor=[Drawing.Color]::Gainsboro;$form.Controls.Add($log)
    function cfg { $h=@{};foreach($k in $boxes.Keys){$h[$k]=$boxes[$k].Text.Trim()};$h }
    function append([string]$t){$log.AppendText("[$(Get-Date -Format HH:mm:ss)] $t`r`n");$log.ScrollToCaret();[Windows.Forms.Application]::DoEvents()}
    $detect.Add_Click({$d=Get-AutomaticEnvironment;foreach($p in $d.PSObject.Properties){if($boxes.ContainsKey($p.Name)-and -not [string]::IsNullOrWhiteSpace([string]$p.Value)){$boxes[$p.Name].Text=[string]$p.Value}};append 'Environment detection completed.'})
    $test.Add_Click({try{Test-AutomationConfiguration (cfg);append 'Configuration and SQL connection validated.';[Windows.Forms.MessageBox]::Show('Validation succeeded.','Daily Patch')|Out-Null}catch{append "ERROR: $($_.Exception.Message)";[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Validation error','OK','Error')|Out-Null}})
    $install.Add_Click({try{append 'Installing ImportExcel...';Install-Module ImportExcel -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop;append 'ImportExcel installed.'}catch{append "ERROR: $($_.Exception.Message)"}})
    $run.Add_Click({$run.Enabled=$false;try{$c=cfg;$c|ConvertTo-Json|Set-Content -LiteralPath $ConfigFile -Encoding UTF8;append 'Starting stage 1...';$old=[Console]::Out;$sw=New-Object IO.StringWriter;[Console]::SetOut($sw);try{$result=Invoke-FullAutomation $c}finally{[Console]::SetOut($old);append $sw.ToString()};append "SUCCESS: $($result.FullName)";[Windows.Forms.MessageBox]::Show("Process completed successfully.`n$($result.FullName)",'Daily Patch')|Out-Null}catch{append "FATAL: $($_.Exception.Message)";[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Process interrupted','OK','Error')|Out-Null}finally{$run.Enabled=$true}})
    [void]$form.ShowDialog()
}

try {
    if($NoGui){
        if(-not (Test-Path -LiteralPath $ConfigFile)){throw "Config file not found: $ConfigFile"}
        $obj=Get-Content -LiteralPath $ConfigFile -Raw|ConvertFrom-Json;$cfg=@{};$obj.PSObject.Properties|%{$cfg[$_.Name]=$_.Value};Invoke-FullAutomation $cfg|Out-Null
    } else { Show-AutomationGui }
    exit 0
} catch { Write-Host "FATAL: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
